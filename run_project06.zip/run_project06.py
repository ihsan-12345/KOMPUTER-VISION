#!/usr/bin/env python3
"""
Runner Project Modul 6 (Python):
- Menjalankan script 18, 19, 20 secara berurutan.
- Mengarahkan output ke folder terpisah: output_project06/
- Tidak mencampur hasil ke praktikum/output.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

MODULE_DIR = Path(__file__).resolve().parent
PRAKTIKUM_DIR = MODULE_DIR / "praktikum"
ROOT_DIR = MODULE_DIR.parent

# Prioritaskan python dari venv repo, fallback ke interpreter saat ini.
VENV_PYTHON = ROOT_DIR / ".venv" / "bin" / "python"
PYTHON_BIN = VENV_PYTHON if VENV_PYTHON.exists() else Path(sys.executable)

OUTPUT_ROOT = MODULE_DIR / "output_project06"
LOG_FILE = OUTPUT_ROOT / "project06_run.log"

SCRIPTS = [
    ("18_document_stitching.py", "18_document_stitching"),
    ("19_panorama_pipeline_lengkap.py", "19_panorama_pipeline_lengkap"),
    ("20_proyek_panorama_app.py", "20_proyek_panorama_app"),
]


def log_write(log_fp, text: str) -> None:
    print(text)
    log_fp.write(text + "\n")
    log_fp.flush()


def run_one_script(log_fp, script_name: str, out_subdir: str) -> int:
    script_path = PRAKTIKUM_DIR / script_name
    if not script_path.exists():
        log_write(log_fp, f"[ERROR] Script tidak ditemukan: {script_path}")
        return 1

    dedicated_out = OUTPUT_ROOT / out_subdir
    dedicated_out.mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["PROJECT06_OUTPUT_DIR"] = str(dedicated_out)

    log_write(log_fp, "")
    log_write(log_fp, f"[RUN] {script_name}")
    log_write(log_fp, f"      Output -> {dedicated_out}")

    start = time.time()
    proc = subprocess.Popen(
        [str(PYTHON_BIN), script_name],
        cwd=str(PRAKTIKUM_DIR),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip("\n")
        print(line)
        log_fp.write(line + "\n")
    proc.wait()

    elapsed = time.time() - start
    if proc.returncode == 0:
        log_write(log_fp, f"[OK] {script_name} selesai dalam {elapsed:.1f}s")
    else:
        log_write(log_fp, f"[FAIL] {script_name} gagal setelah {elapsed:.1f}s")
    return int(proc.returncode)


def main() -> int:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    with LOG_FILE.open("w", encoding="utf-8") as log_fp:
        log_write(log_fp, "============================================================")
        log_write(log_fp, "RUNNER PROJECT MODUL 6 (PYTHON)")
        log_write(log_fp, "IMAGE STITCHING DAN ALIGNMENT")
        log_write(log_fp, f"Waktu mulai: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        log_write(log_fp, f"Python: {PYTHON_BIN}")
        log_write(log_fp, "============================================================")

        for script_name, out_subdir in SCRIPTS:
            code = run_one_script(log_fp, script_name, out_subdir)
            if code != 0:
                log_write(log_fp, "")
                log_write(log_fp, "Runner dihentikan karena ada script yang gagal.")
                log_write(log_fp, f"Log tersimpan di: {LOG_FILE}")
                return code

        log_write(log_fp, "")
        log_write(log_fp, "============================================================")
        log_write(log_fp, "SEMUA SCRIPT BERHASIL DIJALANKAN")
        log_write(log_fp, f"Waktu selesai: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        log_write(log_fp, f"Log tersimpan di: {LOG_FILE}")
        log_write(log_fp, f"Output terpisah tersimpan di: {OUTPUT_ROOT}")
        log_write(log_fp, "============================================================")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
