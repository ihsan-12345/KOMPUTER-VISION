#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="/home/ihsan/Praktikum-Komputer-Vision/.venv/bin/python"

if [[ ! -x "$PYTHON_BIN" ]]; then
  echo "[ERROR] Python venv tidak ditemukan di: $PYTHON_BIN"
  echo "Aktifkan/buat venv lalu install dependency dari requirements.txt"
  exit 1
fi

cd "$SCRIPT_DIR"

echo "[1/3] Menjalankan 19_feature_matching_pipeline.py"
"$PYTHON_BIN" 19_feature_matching_pipeline.py

echo "[2/3] Menjalankan 20_proyek_feature_matching_app.py"
"$PYTHON_BIN" 20_proyek_feature_matching_app.py

echo "[3/3] Menjalankan 15_image_retrieval.py"
"$PYTHON_BIN" 15_image_retrieval.py

echo "Selesai. Semua output ada di folder: $SCRIPT_DIR/output"
