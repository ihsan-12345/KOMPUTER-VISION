#!/usr/bin/env python3
"""Project Modul 3: Pemrosesan Citra end-to-end.

Pipeline mencakup:
- CLAHE + bilateral filter
- Segmentasi HSV (merah dua rentang + hijau)
- Otsu vs adaptive threshold
- Canny edge
- Morfologi (erosi, dilasi, opening, closing)
- Connected Components + statistik area
- FFT magnitude + low-pass/high-pass filtering
- Visualisasi subplot dan penyimpanan output batch
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import cv2
import matplotlib.pyplot as plt
import numpy as np


# Semua parameter penting diletakkan terpusat di bagian atas file.
PARAMS: dict[str, Any] = {
    "clahe_clip": 2.5,
    "clahe_tile": (8, 8),
    "bilateral_d": 9,
    "bilateral_sigma_color": 75,
    "bilateral_sigma_space": 75,
    "hsv_ranges": {
        "red_1": ((0, 80, 80), (10, 255, 255)),
        "red_2": ((160, 80, 80), (179, 255, 255)),
        "green": ((35, 50, 50), (90, 255, 255)),
    },
    "adaptive_block_size": 31,
    "adaptive_c": 5,
    "canny_low": 80,
    "canny_high": 160,
    "kernel_size": 5,
    "erode_iter": 1,
    "dilate_iter": 1,
    "open_iter": 1,
    "close_iter": 1,
    "min_area": 120,
    "max_area": 200000,
    "fft_filter": "lowpass",  # opsi: lowpass | highpass
    "fft_radius": 35,
}


@dataclass
class ComponentStat:
    label: int
    area: int
    x: int
    y: int
    w: int
    h: int
    cx: float
    cy: float


def ensure_odd(value: int) -> int:
    return value if value % 2 == 1 else value + 1


def preprocess_bgr(img_bgr: np.ndarray, params: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)

    clahe = cv2.createCLAHE(
        clipLimit=float(params["clahe_clip"]),
        tileGridSize=tuple(params["clahe_tile"]),
    )
    l_eq = clahe.apply(l)
    lab_eq = cv2.merge((l_eq, a, b))
    clahe_bgr = cv2.cvtColor(lab_eq, cv2.COLOR_LAB2BGR)

    bilateral = cv2.bilateralFilter(
        clahe_bgr,
        d=int(params["bilateral_d"]),
        sigmaColor=float(params["bilateral_sigma_color"]),
        sigmaSpace=float(params["bilateral_sigma_space"]),
    )
    gray = cv2.cvtColor(bilateral, cv2.COLOR_BGR2GRAY)
    return clahe_bgr, bilateral, gray


def segment_hsv(img_bgr: np.ndarray, params: dict[str, Any]) -> dict[str, np.ndarray]:
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    ranges = params["hsv_ranges"]

    red_1 = cv2.inRange(
        hsv,
        np.array(ranges["red_1"][0], dtype=np.uint8),
        np.array(ranges["red_1"][1], dtype=np.uint8),
    )
    red_2 = cv2.inRange(
        hsv,
        np.array(ranges["red_2"][0], dtype=np.uint8),
        np.array(ranges["red_2"][1], dtype=np.uint8),
    )
    mask_red = cv2.bitwise_or(red_1, red_2)

    mask_green = cv2.inRange(
        hsv,
        np.array(ranges["green"][0], dtype=np.uint8),
        np.array(ranges["green"][1], dtype=np.uint8),
    )
    mask_combined = cv2.bitwise_or(mask_red, mask_green)
    return {
        "hsv": hsv,
        "red": mask_red,
        "green": mask_green,
        "combined": mask_combined,
    }


def threshold_compare(gray: np.ndarray, params: dict[str, Any]) -> tuple[np.ndarray, np.ndarray, float]:
    otsu_t, otsu_bin = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU,
    )

    block_size = ensure_odd(int(params["adaptive_block_size"]))
    adaptive_bin = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        block_size,
        int(params["adaptive_c"]),
    )
    return otsu_bin, adaptive_bin, float(otsu_t)


def morphology_refine(mask: np.ndarray, params: dict[str, Any]) -> dict[str, np.ndarray]:
    ksize = int(params["kernel_size"])
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))

    eroded = cv2.erode(mask, kernel, iterations=int(params["erode_iter"]))
    dilated = cv2.dilate(mask, kernel, iterations=int(params["dilate_iter"]))
    opened = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=int(params["open_iter"]))
    closed = cv2.morphologyEx(opened, cv2.MORPH_CLOSE, kernel, iterations=int(params["close_iter"]))

    return {
        "eroded": eroded,
        "dilated": dilated,
        "opened": opened,
        "closed": closed,
    }


def analyze_components(mask: np.ndarray, params: dict[str, Any], base_bgr: np.ndarray) -> tuple[np.ndarray, list[ComponentStat], dict[str, Any]]:
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(mask, connectivity=8)

    min_area = int(params["min_area"])
    max_area = int(params["max_area"])

    overlay = base_bgr.copy()
    selected: list[ComponentStat] = []

    for label in range(1, num_labels):
        x, y, w, h, area = stats[label]
        if area < min_area or area > max_area:
            continue

        cx, cy = centroids[label]
        comp = ComponentStat(
            label=label,
            area=int(area),
            x=int(x),
            y=int(y),
            w=int(w),
            h=int(h),
            cx=float(cx),
            cy=float(cy),
        )
        selected.append(comp)

        cv2.rectangle(overlay, (comp.x, comp.y), (comp.x + comp.w, comp.y + comp.h), (0, 255, 255), 2)
        cv2.circle(overlay, (int(comp.cx), int(comp.cy)), 3, (255, 0, 255), -1)
        cv2.putText(
            overlay,
            f"#{comp.label}:{comp.area}",
            (comp.x, max(16, comp.y - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (0, 255, 255),
            1,
            cv2.LINE_AA,
        )

    areas = [c.area for c in selected]
    count = len(areas)
    mean_area = float(np.mean(areas)) if areas else 0.0
    max_area_found = int(max(areas)) if areas else 0

    size_bins = {
        "small_<500": 0,
        "medium_500_2000": 0,
        "large_>=2000": 0,
    }
    for area in areas:
        if area < 500:
            size_bins["small_<500"] += 1
        elif area < 2000:
            size_bins["medium_500_2000"] += 1
        else:
            size_bins["large_>=2000"] += 1

    stats_summary = {
        "object_count": count,
        "mean_area": mean_area,
        "largest_area": max_area_found,
        "size_distribution": size_bins,
    }

    return overlay, selected, stats_summary


def fourier_analysis(gray: np.ndarray, params: dict[str, Any]) -> dict[str, np.ndarray]:
    h, w = gray.shape
    fft = np.fft.fft2(gray)
    fshift = np.fft.fftshift(fft)

    magnitude = np.log1p(np.abs(fshift))
    magnitude_vis = cv2.normalize(magnitude, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    cy, cx = h // 2, w // 2
    y, x = np.ogrid[:h, :w]
    dist2 = (x - cx) ** 2 + (y - cy) ** 2
    radius2 = int(params["fft_radius"]) ** 2

    if str(params["fft_filter"]).lower() == "highpass":
        freq_mask = (dist2 >= radius2).astype(np.float32)
    else:
        freq_mask = (dist2 <= radius2).astype(np.float32)

    filtered_shift = fshift * freq_mask
    inv_shift = np.fft.ifftshift(filtered_shift)
    recon = np.fft.ifft2(inv_shift)
    recon_mag = np.abs(recon)
    recon_vis = cv2.normalize(recon_mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    return {
        "magnitude": magnitude_vis,
        "freq_mask": (freq_mask * 255).astype(np.uint8),
        "filtered_spatial": recon_vis,
    }


def save_component_csv(csv_path: Path, components: list[ComponentStat]) -> None:
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["label", "area", "x", "y", "w", "h", "cx", "cy"])
        for c in components:
            writer.writerow([c.label, c.area, c.x, c.y, c.w, c.h, f"{c.cx:.2f}", f"{c.cy:.2f}"])


def save_stats_txt(txt_path: Path, image_name: str, otsu_value: float, summary: dict[str, Any]) -> None:
    lines = [
        f"Image: {image_name}",
        f"Otsu threshold: {otsu_value:.2f}",
        f"Jumlah objek valid: {summary['object_count']}",
        f"Area rata-rata: {summary['mean_area']:.2f}",
        f"Objek terbesar (area): {summary['largest_area']}",
        "Distribusi ukuran:",
        f"  - small_<500: {summary['size_distribution']['small_<500']}",
        f"  - medium_500_2000: {summary['size_distribution']['medium_500_2000']}",
        f"  - large_>=2000: {summary['size_distribution']['large_>=2000']}",
    ]
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def visualize_and_save(
    results: dict[str, np.ndarray],
    output_dir: Path,
    image_stem: str,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(4, 4, figsize=(18, 14))
    fig.suptitle(f"Pipeline Summary - {image_stem}", fontsize=14)

    grid = [
        ("Input BGR", results["input_bgr"], "bgr"),
        ("CLAHE LAB", results["clahe_bgr"], "bgr"),
        ("Bilateral", results["bilateral_bgr"], "bgr"),
        ("Gray", results["gray"], "gray"),
        ("Mask Red", results["mask_red"], "gray"),
        ("Mask Green", results["mask_green"], "gray"),
        ("Mask Combined", results["mask_combined"], "gray"),
        ("Otsu Binary", results["otsu_bin"], "gray"),
        ("Adaptive Binary", results["adaptive_bin"], "gray"),
        ("Canny Edge", results["canny"], "gray"),
        ("Erode", results["eroded"], "gray"),
        ("Close(Open(mask))", results["closed"], "gray"),
        ("Connected Components", results["components_overlay"], "bgr"),
        ("FFT Magnitude", results["fft_magnitude"], "gray"),
        ("FFT Filter Mask", results["fft_mask"], "gray"),
        ("IFFT Filtered", results["fft_filtered"], "gray"),
    ]

    for ax, (title, img, mode) in zip(axes.ravel(), grid):
        if mode == "bgr":
            ax.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        else:
            ax.imshow(img, cmap="gray")
        ax.set_title(title)
        ax.axis("off")

    fig.tight_layout()
    fig.savefig(output_dir / f"{image_stem}_pipeline_summary.png", dpi=160)
    plt.close(fig)


def process_image(image_path: Path, output_root: Path, params: dict[str, Any]) -> dict[str, Any]:
    img_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if img_bgr is None:
        raise ValueError(f"Gagal membaca gambar: {image_path}")

    clahe_bgr, bilateral_bgr, gray = preprocess_bgr(img_bgr, params)
    hsv_masks = segment_hsv(bilateral_bgr, params)
    otsu_bin, adaptive_bin, otsu_value = threshold_compare(gray, params)

    canny = cv2.Canny(gray, int(params["canny_low"]), int(params["canny_high"]))

    morph = morphology_refine(hsv_masks["combined"], params)
    components_overlay, components, summary = analyze_components(morph["closed"], params, bilateral_bgr)

    fft_data = fourier_analysis(gray, params)

    image_out = output_root / image_path.stem
    image_out.mkdir(parents=True, exist_ok=True)

    cv2.imwrite(str(image_out / f"{image_path.stem}_mask_warna.png"), hsv_masks["combined"])
    cv2.imwrite(str(image_out / f"{image_path.stem}_edges_canny.png"), canny)
    cv2.imwrite(str(image_out / f"{image_path.stem}_components_labeled.png"), components_overlay)
    cv2.imwrite(str(image_out / f"{image_path.stem}_fourier_magnitude.png"), fft_data["magnitude"])

    save_component_csv(image_out / f"{image_path.stem}_components.csv", components)
    save_stats_txt(image_out / f"{image_path.stem}_statistik.txt", image_path.name, otsu_value, summary)

    visualization_results = {
        "input_bgr": img_bgr,
        "clahe_bgr": clahe_bgr,
        "bilateral_bgr": bilateral_bgr,
        "gray": gray,
        "mask_red": hsv_masks["red"],
        "mask_green": hsv_masks["green"],
        "mask_combined": hsv_masks["combined"],
        "otsu_bin": otsu_bin,
        "adaptive_bin": adaptive_bin,
        "canny": canny,
        "eroded": morph["eroded"],
        "closed": morph["closed"],
        "components_overlay": components_overlay,
        "fft_magnitude": fft_data["magnitude"],
        "fft_mask": fft_data["freq_mask"],
        "fft_filtered": fft_data["filtered_spatial"],
    }
    visualize_and_save(visualization_results, image_out, image_path.stem)

    return {
        "image": image_path.name,
        "otsu_threshold": f"{otsu_value:.2f}",
        "object_count": summary["object_count"],
        "mean_area": f"{summary['mean_area']:.2f}",
        "largest_area": summary["largest_area"],
        "small_<500": summary["size_distribution"]["small_<500"],
        "medium_500_2000": summary["size_distribution"]["medium_500_2000"],
        "large_>=2000": summary["size_distribution"]["large_>=2000"],
    }


def collect_images(input_path: Path) -> list[Path]:
    valid_ext = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
    if input_path.is_file():
        return [input_path]

    images = [p for p in sorted(input_path.iterdir()) if p.suffix.lower() in valid_ext]
    if not images:
        raise FileNotFoundError(f"Tidak ada gambar valid pada folder: {input_path}")
    return images


def write_batch_summary(rows: list[dict[str, Any]], output_csv: Path) -> None:
    if not rows:
        return

    with output_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description="Project Modul 3 - Pipeline Pemrosesan Citra")
    parser.add_argument(
        "--input",
        type=str,
        default=str(repo_root / "sample_images"),
        help="Path file/folder input gambar",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=str(Path(__file__).resolve().parent / "output_project_m03"),
        help="Folder output hasil pipeline",
    )
    parser.add_argument(
        "--fft-filter",
        type=str,
        choices=["lowpass", "highpass"],
        default=PARAMS["fft_filter"],
        help="Jenis filter domain frekuensi",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_path = Path(args.input)
    output_root = Path(args.output)
    output_root.mkdir(parents=True, exist_ok=True)

    run_params = dict(PARAMS)
    run_params["fft_filter"] = args.fft_filter

    image_paths = collect_images(input_path)
    summary_rows: list[dict[str, Any]] = []

    print(f"[INFO] Memproses {len(image_paths)} gambar dari: {input_path}")
    for image_path in image_paths:
        row = process_image(image_path, output_root, run_params)
        summary_rows.append(row)
        print(
            "[OK] "
            f"{row['image']} -> objects={row['object_count']}, "
            f"mean_area={row['mean_area']}, largest={row['largest_area']}"
        )

    write_batch_summary(summary_rows, output_root / "batch_summary.csv")
    print(f"[DONE] Ringkasan batch: {output_root / 'batch_summary.csv'}")


if __name__ == "__main__":
    main()
