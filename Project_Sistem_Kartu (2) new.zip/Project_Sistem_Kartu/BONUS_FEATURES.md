# 🆕 FITUR BONUS - SmartAttend System v1.0

## ✨ Fitur-Fitur Bonus yang Sudah Diimplementasi

---

## 1. 🔍 **Image Quality Check** (Menu 7)

Fitur untuk menganalisa kualitas gambar kartu secara detail.

### Fitur:
- ✅ **Blur Detection** - Deteksi apakah gambar blur atau sharp
- ✅ **Brightness Analysis** - Analisis tingkat kecerahan gambar
- ✅ **Contrast Analysis** - Analisis tingkat kontras gambar
- ✅ **Card Orientation Detection** - Deteksi orientasi kartu (portrait/landscape)
- ✅ **Face Detection** - Deteksi wajah di kartu identitas
- ✅ **Quality Score** (0-100) - Skor kualitas keseluruhan

### Cara Pakai:
```
Main Menu → Pilih 7 → Masukkan path gambar (atau Enter untuk auto)
```

### Output:
```
✓ Image Quality Score: 85/100

==================================================
  Image Quality Analysis
==================================================
  Overall Score: 85/100

  Blur: 95% - Sharp
  Brightness: 95% - Level: 145
  Contrast: 70% - Std Dev: 45
==================================================

📐 Card Orientation Detection:
   Orientation: LANDSCAPE
   Aspect Ratio: 1.50
   Confidence: HIGH

👤 Face Detection:
   ✅ 1 wajah terdeteksi
```

---

## 2. ✨ **Auto Enhancement** (Menu 8)

Fitur untuk otomatis meningkatkan kualitas gambar yang kurang baik.

### Teknologi:
- ✅ **Histogram Equalization** - Pemerataan histogram untuk kontras optimal
- ✅ **CLAHE (Contrast Limited Adaptive Histogram Equalization)** - Enhancement adaptive level tile
- ✅ **HSV Processing** - Pemrosesan pada channel Value untuk hasil lebih baik

### Cara Pakai:
```
Main Menu → Pilih 8 → Masukkan path gambar (atau Enter untuk auto)
```

### Hasil:
Program akan:
1. Show quality sebelum enhancement
2. Apply auto enhancement
3. Show quality sesudah enhancement
4. Preview perbandingan before/after
5. Opsi untuk simpan hasil

### Contoh:
```
SEBELUM Enhancement:
  Overall Score: 45/100
  Blur: 40% - Blurry
  Brightness: 60% - Level: 89
  Contrast: 20% - Std Dev: 8

SESUDAH Enhancement:
  Overall Score: 78/100
  Blur: 65% - Sharp Enough
  Brightness: 85% - Level: 142
  Contrast: 80% - Std Dev: 52

✅ Hasil disimpan: output/2026-03-01/enhanced_kartu.jpg
```

---

## 3. 🔎 **Duplicate Detection** (Menu 9)

Fitur untuk mencari gambar-gambar duplikat dalam folder input.

### Cara Kerja:
- Menggunakan **Histogram Comparison** untuk mendeteksi kemiripan
- Membandingkan semua pasangan gambar
- Mengelompokkan gambar yang mirip (threshold default 0.95)

### Cara Pakai:
```
Main Menu → Pilih 9
```

### Output Contoh:
```
📁 Scanning folder: input
✓ Loaded 10 images

Similarity threshold (0.7-0.99, default 0.95): 0.90

🔍 Scanning for duplicates (threshold: 0.90)...

Ditemukan 2 grup duplikat:

Group 1:
  - ktm_foto1.jpg
  - ktm_foto1_copy.jpg

Group 2:
  - ktm_scan.jpg
  - ktm_scan_v2.jpg
```

---

## 4. 📊 **Export Report** (Menu 10)

Fitur untuk export statistik hasil pemrosesan ke format JSON atau CSV.

### Format Export:
- ✅ **JSON** - Untuk analisis lebih lanjut
- ✅ **CSV** - Untuk import ke Excel/Google Sheets

### Cara Pakai:
```
Main Menu → Pilih 10 → Pilih format (1=JSON atau 2=CSV)
```

### Output File:
```
Location: output/report_20260301_153045.json
```

### Contoh Output JSON:
```json
{
  "generated_at": "2026-03-01T15:30:45.123456",
  "folder": "output",
  "files": [
    {
      "filename": "20260301_083045_kartu.jpg",
      "path": "output/2026-03-01/20260301_083045_kartu.jpg",
      "size_bytes": 45280,
      "quality_score": 82
    },
    {
      "filename": "20260301_091530_kartu.jpg",
      "path": "output/2026-03-01/20260301_091530_kartu.jpg",
      "size_bytes": 48920,
      "quality_score": 88
    }
  ],
  "summary": {
    "total_files": 12,
    "total_size_bytes": 582450,
    "average_quality": 85
  }
}
```

### Contoh Output CSV:
```
Filename,Size (bytes),Quality Score
20260301_083045_kartu.jpg,45280,82
20260301_091530_kartu.jpg,48920,88
20260301_105015_kartu.jpg,46150,85
...
```

---

## 🧪 Bonus Features dalam Module

Semua fitur ini ada di file **`enhancement_module.py`** dan bisa digunakan secara langsung:

### 1. Face Detection
```python
from enhancement_module import detect_face, draw_face_rectangles

faces = detect_face(image)
image_with_faces = draw_face_rectangles(image, faces)
```

### 2. Quality Scoring
```python
from enhancement_module import calculate_image_quality_score, display_quality_report

scores = calculate_image_quality_score(image)
display_quality_report(image)
```

### 3. Auto Enhancement
```python
from enhancement_module import auto_enhance_image

enhanced = auto_enhance_image(image, apply_histogram_eq=True, apply_clahe=True)
```

### 4. Image Similarity
```python
from enhancement_module import calculate_image_similarity

similarity = calculate_image_similarity(img1, img2)
# Returns: 0.0 to 1.0 (1.0 = identical)
```

### 5. Batch Operations
```python
from enhancement_module import batch_auto_enhance, apply_quality_filter

enhanced_list = batch_auto_enhance(image_list)
passed, rejected = apply_quality_filter(image_list, min_score=60)
```

---

## 📋 Quick Reference

| Menu | Fitur | Gunakan Ketika |
|------|-------|----------------|
| 7 | Image Quality Check | Ingin tahu detail kualitas gambar |
| 8 | Auto Enhancement | Gambar terlalu gelap/blur ingin diperbaiki |
| 9 | Duplicate Detection | Ingin cari gambar yang sama |
| 10 | Export Report | Ingin laporan hasil untuk presentasi |

---

## 🎯 Use Cases

### Scenario 1: QC Gambar Kartu
```
1. Batch upload foto KTM ke folder input/
2. Pilih menu 9 (Duplicate Detection) - pastikan tidak ada duplikat
3. Proses dengan menu 2 (Multiple Images)
4. Cek quality dengan menu 7 untuk yang kurang bagus
5. Auto enhance dengan menu 8
6. Export report dengan menu 10 untuk approval
```

### Scenario 2: Perbaikan Gambar Massal
```
1. Folder input/ berisi foto KTM berkualitas rendah
2. Pilih menu 8 (Auto Enhancement) untuk setiap gambar
3. Atau gunakan function enhance batch operation
4. Process hasil enhancement dengan menu 1/2
5. Export report hasil akhir
```

### Scenario 3: Audit & Reporting
```
1. Setelah selesai proses semua gambar
2. Pilih menu 10 (Export Report)
3. Export ke JSON format
4. Import ke spreadsheet untuk analisis
5. Generate grafik dan statistik
```

---

## 💡 Tips Penggunaan

1. **Quality Score Interpretation:**
   - 80-100: ✅ Sangat bagus
   - 60-79: ✅ Cukup bagus
   - 40-59: ⚠️ Kurang baik, pertimbangkan enhancement
   - <40: ❌ Buruk, gunakan auto enhancement

2. **Batch Processing:**
   - Gunakan menu 2 jika ada banyak gambar
   - Atau import `batch_auto_enhance()` di enhancement_module.py

3. **Duplicate Detection:**
   - Default threshold 0.95 (sangat strict)
   - Turunkan ke 0.85 untuk deteksi duplikat yang lebih lenient

4. **Export Report:**
   - JSON lebih detail, cocok untuk processing
   - CSV lebih mudah dibuka di Excel

---

## 🔧 Teknologi yang Digunakan

- **OpenCV Cascade Classifier** - Face Detection
- **Laplacian Variance** - Blur Detection
- **Histogram Equalization** - Contrast Enhancement
- **CLAHE** - Adaptive Contrast Enhancement
- **Histogram Comparison** - Image Similarity

---

## 📊 File Output

Semua file bonus output disimpan terorganisir:

```
output/
├── 2026-03-01/           ← Hasil per tanggal
│   ├── 20260301_083045_kartu.jpg
│   └── enhanced_kartu.jpg    ← Dari Auto Enhancement
│
├── collages/             ← Collage dari menu 4
│   └── summary_2026-03-01.jpg
│
└── report_20260301_153045.json   ← Dari Export Report
```

---

## 🚀 Contoh Lengkap

### Workflow Lengkap dengan Fitur Bonus:

```
1. Siapkan foto KTM di folder input/

2. Jalankan Main Menu -> 7 (Check Quality)
   - Lihat score kualitas masing-masing gambar

3. Jika score < 60, gunakan Menu 8 (Auto Enhancement)
   - Auto perbaiki gambar yang kurang bagus

4. Menu 9 (Duplicate Detection)
   - Pastikan tidak ada duplikat dalam input

5. Menu 2 (Process Multiple Images)
   - Batch process semua gambar

6. Menu 4 (Create Collage)
   - Buat daily summary collage

7. Menu 10 (Export Report)
   - Export statistik untuk dokumentasi
```

---

## ✅ Checklist Fitur Bonus

| Fitur | Status | Keterangan |
|-------|--------|-----------|
| Face Detection | ✅ | detectFace() + draw_face_rectangles() |
| Quality Check | ✅ | calculate_image_quality_score() |
| Blur Detection | ✅ | Using Laplacian Variance |
| Brightness Analysis | ✅ | Mean intensity calculation |
| Contrast Analysis | ✅ | Standard deviation calculation |
| Orientation Detection | ✅ | Aspect ratio analysis |
| Auto Enhancement | ✅ | Histogram + CLAHE |
| Duplicate Detection | ✅ | Histogram Comparison |
| Image Similarity | ✅ | BHATTACHARYYA distance |
| Batch Operations | ✅ | batch_auto_enhance(), apply_quality_filter() |
| Export JSON Report | ✅ | Full statistics export |
| Export CSV Report | ✅ | Simple CSV format |
| GUI Integration | ✅ | Semua di Main Menu |

---

**Semua fitur ini **SUDAH SIAP** dan dapat digunakan langsung dari Menu Utama! 🎉**

Nikmati enhancement untuk project SmartAttend Anda! ✨
