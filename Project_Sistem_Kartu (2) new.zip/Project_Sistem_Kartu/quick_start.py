# quick_start.py
# Quick start guide untuk SmartAttend System

import os
import sys

def print_colored_banner():
    """Print banner dengan box drawing characters"""
    print("""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║              🎓 SMARTATTEND SYSTEM - QUICK START 🎓              ║
║                                                                  ║
║              Sistem Pencatat Kehadiran Digital                   ║
║                Berbasis Kartu Identitas                          ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
    """)

def check_dependencies():
    """Check apakah dependencies sudah terinstall"""
    print("\n📦 Checking dependencies...")
    
    missing = []
    
    try:
        import cv2
        print("  ✅ opencv-python installed")
    except ImportError:
        print("  ❌ opencv-python NOT installed")
        missing.append("opencv-python")
    
    try:
        import numpy
        print("  ✅ numpy installed")
    except ImportError:
        print("  ❌ numpy NOT installed")
        missing.append("numpy")
    
    return missing

def install_dependencies(packages):
    """Install missing dependencies"""
    print(f"\n📥 Installing missing packages: {', '.join(packages)}")
    print("   This may take a few minutes...\n")
    
    import subprocess
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + packages)
        print("\n✅ All packages installed successfully!")
        return True
    except subprocess.CalledProcessError:
        print("\n❌ Failed to install packages")
        return False

def show_menu():
    """Show quick start menu"""
    print("\n" + "="*70)
    print("                        QUICK START OPTIONS")
    print("="*70)
    print("\n1. 🧪 Run Test Suite (Recommended for first time)")
    print("   - Creates sample images")
    print("   - Tests all features")
    print("   - Shows you how everything works")
    
    print("\n2. 🚀 Run Main Application")
    print("   - Interactive menu")
    print("   - Process your own images")
    print("   - Requires images in 'input/' folder")
    
    print("\n3. 📚 View Documentation")
    print("   - Read README.md")
    
    print("\n4. ✅ Check System Requirements")
    print("   - Verify installation")
    
    print("\n0. ❌ Exit")
    print("="*70)

def open_readme():
    """Open README.md"""
    readme_path = "README.md"
    if os.path.exists(readme_path):
        # Try to open with default text editor
        if os.name == 'nt':  # Windows
            os.system(f'start {readme_path}')
        elif os.name == 'posix':  # Linux/Mac
            os.system(f'open {readme_path} || xdg-open {readme_path}')
        print("✅ Opening README.md...")
    else:
        print("❌ README.md not found")

def check_system():
    """Check system requirements"""
    print("\n" + "="*70)
    print("                    SYSTEM CHECK")
    print("="*70)
    
    # Python version
    print(f"\n🐍 Python Version: {sys.version.split()[0]}")
    if sys.version_info >= (3, 7):
        print("   ✅ Python version OK (>= 3.7)")
    else:
        print("   ⚠️  Python 3.7+ recommended")
    
    # Dependencies
    missing = check_dependencies()
    
    # Directory structure
    print("\n📁 Checking directory structure...")
    required_dirs = ['input', 'output', 'output/collages']
    required_files = ['config.py', 'main.py', 'capture_module.py', 
                     'process_module.py', 'utils.py']
    
    all_ok = True
    for directory in required_dirs:
        if os.path.exists(directory):
            print(f"   ✅ {directory}/")
        else:
            print(f"   ⚠️  {directory}/ (will be created automatically)")
    
    for file in required_files:
        if os.path.exists(file):
            print(f"   ✅ {file}")
        else:
            print(f"   ❌ {file} MISSING!")
            all_ok = False
    
    print("\n" + "="*70)
    
    if not missing and all_ok:
        print("\n✅ System is ready to use!")
        return True
    elif missing:
        print("\n⚠️  Missing dependencies. Please install them first.")
        return False
    else:
        print("\n❌ Some required files are missing!")
        return False

def main():
    """Main function"""
    print_colored_banner()
    
    print("\n👋 Selamat datang di SmartAttend System!")
    print("   Project Praktikum Computer Vision - Modul 01")
    
    # Initial dependency check
    print("\n🔍 Performing initial check...")
    missing = check_dependencies()
    
    if missing:
        print(f"\n⚠️  Missing dependencies detected: {', '.join(missing)}")
        response = input("\nInstall missing dependencies now? (y/n): ").strip().lower()
        
        if response == 'y':
            if not install_dependencies(missing):
                print("\n❌ Installation failed. Please install manually:")
                print(f"   pip install {' '.join(missing)}")
                sys.exit(1)
            print("\n✅ Dependencies installed! Please restart this script.")
            sys.exit(0)
        else:
            print("\n❌ Cannot continue without dependencies.")
            print("   Install manually: pip install -r requirements.txt")
            sys.exit(1)
    
    # Main menu loop
    while True:
        show_menu()
        
        try:
            choice = input("\nPilih opsi (0-4): ").strip()
            
            if choice == '1':
                print("\n🧪 Running test suite...")
                print("   This will create sample images and test all features.\n")
                os.system(f'{sys.executable} test_system.py')
                input("\nPress Enter to continue...")
            
            elif choice == '2':
                print("\n🚀 Launching main application...")
                print("   Pastikan ada gambar di folder 'input/' terlebih dahulu!\n")
                response = input("Continue? (y/n): ").strip().lower()
                if response == 'y':
                    os.system(f'{sys.executable} main.py')
                input("\nPress Enter to continue...")
            
            elif choice == '3':
                open_readme()
                input("\nPress Enter to continue...")
            
            elif choice == '4':
                check_system()
                input("\nPress Enter to continue...")
            
            elif choice == '0':
                print("\n👋 Terima kasih! Sampai jumpa!")
                sys.exit(0)
            
            else:
                print("\n❌ Pilihan tidak valid!")
                input("Press Enter to continue...")
        
        except KeyboardInterrupt:
            print("\n\n👋 Program dihentikan. Sampai jumpa!")
            sys.exit(0)
        except Exception as e:
            print(f"\n❌ Error: {e}")
            input("Press Enter to continue...")

if __name__ == "__main__":
    main()
