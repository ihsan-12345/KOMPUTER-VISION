# start_debug.py
# Script untuk debugging - jalankan ini jika main.py bermasalah

import sys
import os

print("="*70)
print("           SMARTATTEND - DEBUG MODE")
print("="*70)

print("\n1. Checking Python version...")
print(f"   Python: {sys.version}")
print(f"   Version: {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")

print("\n2. Checking working directory...")
print(f"   CWD: {os.getcwd()}")

print("\n3. Checking required modules...")

modules_to_check = {
    'cv2': 'opencv-python',
    'numpy': 'numpy',
}

missing = []
for module, package in modules_to_check.items():
    try:
        __import__(module)
        print(f"   ✅ {module} (from {package})")
    except ImportError:
        print(f"   ❌ {module} NOT FOUND - install: pip install {package}")
        missing.append(package)

print("\n4. Checking project files...")
required_files = [
    'config.py',
    'main.py',
    'capture_module.py',
    'process_module.py',
    'utils.py'
]

for filename in required_files:
    if os.path.exists(filename):
        print(f"   ✅ {filename}")
    else:
        print(f"   ❌ {filename} MISSING!")

print("\n5. Checking folders...")
folders = ['input', 'output']
for folder in folders:
    if os.path.exists(folder):
        print(f"   ✅ {folder}/")
    else:
        print(f"   ⚠️  {folder}/ (will be created)")

print("\n" + "="*70)

if missing:
    print("\n❌ ERROR: Missing required packages!")
    print(f"   Install with: pip install {' '.join(missing)}")
    print("\n   Or: pip install -r requirements.txt")
else:
    print("\n✅ All checks passed!")
    
    print("\n" + "="*70)
    print("Testing basic imports...")
    print("="*70)
    
    try:
        print("\nImporting config...")
        from config import *
        print("✅ config imported")
        
        print("\nImporting capture_module...")
        from capture_module import *
        print("✅ capture_module imported")
        
        print("\nImporting process_module...")
        from process_module import *
        print("✅ process_module imported")
        
        print("\nImporting utils...")
        from utils import *
        print("✅ utils imported")
        
        print("\n" + "="*70)
        print("✅ ALL IMPORTS SUCCESSFUL!")
        print("="*70)
        
        print("\nTesting basic functions...")
        ensure_directories()
        print("✅ Directories created/verified")
        
        print("\n" + "="*70)
        print("🎉 SYSTEM IS READY!")
        print("="*70)
        
        response = input("\nRun main program now? (y/n): ").strip().lower()
        if response == 'y':
            print("\nStarting main.py...\n")
            import main
        else:
            print("\nYou can now run: python main.py")
            
    except Exception as e:
        print(f"\n❌ ERROR during import test:")
        print(f"   {e}")
        print(f"   Type: {type(e).__name__}")
        import traceback
        traceback.print_exc()

print("\n")
input("Press Enter to exit...")
