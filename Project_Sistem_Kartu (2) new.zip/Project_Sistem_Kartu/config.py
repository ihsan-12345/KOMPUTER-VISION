# config.py
# Konfigurasi untuk Sistem Pencatat Kehadiran Digital Berbasis Kartu Identitas

import os

# ============================================================
# KOMENTAR VIDEO (alur penjelasan konfigurasi)
# 1) Jelaskan bahwa semua parameter global proyek dikontrol dari file ini.
# 2) Tunjukkan bagian penting: dimensi kartu, watermark, timestamp, border.
# 3) Bahas path input/output serta pola nama file hasil otomatis.
# 4) Perlihatkan pengaturan collage dan webcam untuk fitur lanjutan.
# 5) Tutup dengan fungsi `validate_config()` sebagai pengecekan awal runtime.
# ============================================================

# ===== DIMENSI KARTU =====
# Ukuran standar kartu ID yang akan digunakan
CARD_WIDTH = 400
CARD_HEIGHT = 250

# ===== KUALITAS OUTPUT =====
OUTPUT_QUALITY = 95  # Kualitas JPEG (0-100)
OUTPUT_FORMAT = 'jpg'  # Format output

# ===== WATERMARK & BRANDING =====
WATERMARK_TEXT = "SmartAttend v1.0"
WATERMARK_POSITION = (10, 230)  # Posisi watermark (x, y)
WATERMARK_FONT_SCALE = 0.5
WATERMARK_COLOR = (255, 255, 255)  # Warna putih
WATERMARK_THICKNESS = 1

# ===== TIMESTAMP =====
TIMESTAMP_POSITION = (10, 20)  # Posisi timestamp (x, y)
TIMESTAMP_FONT_SCALE = 0.6
TIMESTAMP_COLOR = (255, 255, 255)  # Warna putih
TIMESTAMP_THICKNESS = 2
TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S"

# ===== BORDER/FRAME =====
BORDER_COLOR = (0, 120, 255)  # Warna orange dalam BGR
BORDER_THICKNESS = 3

# ===== PATH & FOLDER =====
# Folder input dan output
INPUT_FOLDER = "input"
OUTPUT_FOLDER = "output"
COLLAGE_FOLDER = os.path.join(OUTPUT_FOLDER, "collages")

# Format nama file output
OUTPUT_FILENAME_FORMAT = "%Y%m%d_%H%M%S_kartu"
COLLAGE_FILENAME_FORMAT = "summary_%Y-%m-%d"

# ===== COLLAGE SETTINGS =====
COLLAGE_GRID_SIZE = (2, 2)  # Grid 2x2
COLLAGE_PADDING = 10  # Jarak antar gambar dalam collage
COLLAGE_TITLE_HEIGHT = 50  # Tinggi area judul di collage
COLLAGE_TITLE_TEXT = "DAILY SUMMARY"
COLLAGE_TITLE_FONT_SCALE = 1.0
COLLAGE_TITLE_COLOR = (255, 255, 255)
COLLAGE_TITLE_BG_COLOR = (50, 50, 50)

# ===== WEBCAM SETTINGS =====
WEBCAM_INDEX = 0  # Index kamera (0 untuk default webcam)
WEBCAM_WAIT_KEY = 3000  # Waktu tunggu sebelum capture (ms)

# ===== BRIGHTNESS & CONTRAST =====
DEFAULT_BRIGHTNESS = 0  # -100 to 100
DEFAULT_CONTRAST = 1.0  # 0.0 to 3.0

# ===== SUPPORTED FORMATS =====
SUPPORTED_IMAGE_FORMATS = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']

# ===== LOGGING =====
LOG_ENABLED = True
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR

# ===== VALIDASI =====
def validate_config():
    """Validasi konfigurasi untuk memastikan nilai yang masuk akal"""
    assert CARD_WIDTH > 0 and CARD_HEIGHT > 0, "Dimensi kartu harus positif"
    assert 0 <= OUTPUT_QUALITY <= 100, "Kualitas output harus antara 0-100"
    assert COLLAGE_GRID_SIZE[0] > 0 and COLLAGE_GRID_SIZE[1] > 0, "Grid size harus positif"
    print("✓ Konfigurasi valid")

if __name__ == "__main__":
    # Test konfigurasi
    print("=== KONFIGURASI SISTEM SMARTATTEND ===")
    print(f"Ukuran Kartu: {CARD_WIDTH}x{CARD_HEIGHT}")
    print(f"Kualitas Output: {OUTPUT_QUALITY}")
    print(f"Watermark: {WATERMARK_TEXT}")
    print(f"Grid Collage: {COLLAGE_GRID_SIZE[0]}x{COLLAGE_GRID_SIZE[1]}")
    validate_config()
