# process_module.py
# Modul untuk pemrosesan gambar kartu identitas

import cv2
import numpy as np
from datetime import datetime
from config import *

# ============================================================
# KOMENTAR VIDEO (alur penjelasan modul process)
# 1) Jelaskan modul ini berisi pipeline inti pemrosesan kartu.
# 2) Tunjukkan urutan umum: resize → brightness/contrast → timestamp → watermark → border.
# 3) Bahas opsi `keep_aspect_ratio` dan kapan perlu dipakai.
# 4) Jelaskan fitur peningkatan visual: histogram equalization + collage builder.
# 5) Tekankan prinsip: fungsi return image baru agar aman dari modifikasi tak sengaja.
# ============================================================

def resize_standard(image, width=CARD_WIDTH, height=CARD_HEIGHT, keep_aspect_ratio=False):
    """
    Resize gambar ke ukuran standar
    
    Args:
        image (numpy.ndarray): Gambar input
        width (int): Lebar target
        height (int): Tinggi target
        keep_aspect_ratio (bool): Jaga aspect ratio atau tidak
        
    Returns:
        numpy.ndarray: Gambar yang telah di-resize
    """
    if image is None:
        print("❌ Error: Gambar None pada resize_standard")
        return None
    
    h, w = image.shape[:2]
    
    if keep_aspect_ratio:
        # Hitung scaling factor
        scale = min(width / w, height / h)
        new_w = int(w * scale)
        new_h = int(h * scale)
        
        # Resize dengan aspect ratio
        resized = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_AREA)
        
        # Create canvas dengan ukuran target
        canvas = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Paste gambar yang di-resize ke tengah canvas
        y_offset = (height - new_h) // 2
        x_offset = (width - new_w) // 2
        canvas[y_offset:y_offset+new_h, x_offset:x_offset+new_w] = resized
        
        if LOG_ENABLED:
            print(f"✓ Resize dengan aspect ratio: {w}x{h} → {new_w}x{new_h} (di canvas {width}x{height})")
        
        return canvas
    else:
        # Resize langsung ke ukuran target
        resized = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
        
        if LOG_ENABLED:
            print(f"✓ Resize: {w}x{h} → {width}x{height}")
        
        return resized


def convert_to_grayscale(image):
    """
    Konversi gambar ke grayscale
    
    Args:
        image (numpy.ndarray): Gambar input
        
    Returns:
        numpy.ndarray: Gambar grayscale
    """
    if image is None:
        return None
    
    if len(image.shape) == 2:
        # Sudah grayscale
        return image
    
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    if LOG_ENABLED:
        print("✓ Konversi ke grayscale")
    
    return gray


def adjust_brightness_contrast(image, brightness=DEFAULT_BRIGHTNESS, contrast=DEFAULT_CONTRAST):
    """
    Adjust brightness dan contrast gambar
    
    Args:
        image (numpy.ndarray): Gambar input
        brightness (int): Nilai brightness adjustment (-100 to 100)
        contrast (float): Nilai contrast multiplier (0.0 to 3.0)
        
    Returns:
        numpy.ndarray: Gambar yang telah di-adjust
    """
    if image is None:
        return None
    
    # Adjust brightness dan contrast
    adjusted = cv2.convertScaleAbs(image, alpha=contrast, beta=brightness)
    
    if LOG_ENABLED and (brightness != 0 or contrast != 1.0):
        print(f"✓ Adjust brightness: {brightness}, contrast: {contrast}")
    
    return adjusted


def add_timestamp(image, timestamp_text=None, position=None):
    """
    Tambahkan timestamp ke gambar
    
    Args:
        image (numpy.ndarray): Gambar input
        timestamp_text (str): Text timestamp (None = generate otomatis)
        position (tuple): Posisi (x, y) untuk timestamp (None = gunakan default)
        
    Returns:
        numpy.ndarray: Gambar dengan timestamp
    """
    if image is None:
        return None
    
    # Generate timestamp jika tidak diberikan
    if timestamp_text is None:
        timestamp_text = datetime.now().strftime(TIMESTAMP_FORMAT)
    
    # Gunakan posisi default jika tidak diberikan
    if position is None:
        position = TIMESTAMP_POSITION
    
    # Copy gambar untuk tidak mengubah original
    result = image.copy()
    
    # Tambahkan background gelap untuk timestamp agar lebih terbaca
    text_size = cv2.getTextSize(timestamp_text, cv2.FONT_HERSHEY_SIMPLEX, 
                                TIMESTAMP_FONT_SCALE, TIMESTAMP_THICKNESS)[0]
    
    # Rectangle untuk background
    bg_x1 = position[0] - 5
    bg_y1 = position[1] - text_size[1] - 5
    bg_x2 = position[0] + text_size[0] + 5
    bg_y2 = position[1] + 5
    
    cv2.rectangle(result, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 0, 0), -1)
    cv2.rectangle(result, (bg_x1, bg_y1), (bg_x2, bg_y2), TIMESTAMP_COLOR, 1)
    
    # Tambahkan text timestamp
    cv2.putText(result, timestamp_text, position, 
                cv2.FONT_HERSHEY_SIMPLEX, TIMESTAMP_FONT_SCALE, 
                TIMESTAMP_COLOR, TIMESTAMP_THICKNESS, cv2.LINE_AA)
    
    if LOG_ENABLED:
        print(f"✓ Timestamp ditambahkan: {timestamp_text}")
    
    return result


def add_watermark(image, watermark_text=WATERMARK_TEXT, position=None):
    """
    Tambahkan watermark ke gambar
    
    Args:
        image (numpy.ndarray): Gambar input
        watermark_text (str): Text watermark
        position (tuple): Posisi (x, y) untuk watermark (None = gunakan default)
        
    Returns:
        numpy.ndarray: Gambar dengan watermark
    """
    if image is None:
        return None
    
    # Gunakan posisi default jika tidak diberikan
    if position is None:
        position = WATERMARK_POSITION
    
    # Copy gambar
    result = image.copy()
    
    # Tambahkan background untuk watermark
    text_size = cv2.getTextSize(watermark_text, cv2.FONT_HERSHEY_SIMPLEX,
                                WATERMARK_FONT_SCALE, WATERMARK_THICKNESS)[0]
    
    bg_x1 = position[0] - 5
    bg_y1 = position[1] - text_size[1] - 5
    bg_x2 = position[0] + text_size[0] + 5
    bg_y2 = position[1] + 5
    
    cv2.rectangle(result, (bg_x1, bg_y1), (bg_x2, bg_y2), (0, 0, 0), -1)
    cv2.rectangle(result, (bg_x1, bg_y1), (bg_x2, bg_y2), WATERMARK_COLOR, 1)
    
    # Tambahkan text watermark
    cv2.putText(result, watermark_text, position,
                cv2.FONT_HERSHEY_SIMPLEX, WATERMARK_FONT_SCALE,
                WATERMARK_COLOR, WATERMARK_THICKNESS, cv2.LINE_AA)
    
    if LOG_ENABLED:
        print(f"✓ Watermark ditambahkan: {watermark_text}")
    
    return result


def add_border(image, color=BORDER_COLOR, thickness=BORDER_THICKNESS):
    """
    Tambahkan border/frame ke gambar
    
    Args:
        image (numpy.ndarray): Gambar input
        color (tuple): Warna border dalam BGR
        thickness (int): Ketebalan border
        
    Returns:
        numpy.ndarray: Gambar dengan border
    """
    if image is None:
        return None
    
    result = image.copy()
    h, w = result.shape[:2]
    
    # Gambar rectangle sebagai border
    cv2.rectangle(result, (0, 0), (w-1, h-1), color, thickness)
    
    if LOG_ENABLED:
        print(f"✓ Border ditambahkan: thickness={thickness}")
    
    return result


def histogram_equalization(image):
    """
    Lakukan histogram equalization untuk meningkatkan kontras
    (Fitur bonus untuk gambar gelap)
    
    Args:
        image (numpy.ndarray): Gambar input
        
    Returns:
        numpy.ndarray: Gambar dengan histogram equalization
    """
    if image is None:
        return None
    
    # Jika gambar berwarna, konversi ke YCrCb dan equalize channel Y
    if len(image.shape) == 3:
        ycrcb = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)
        ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
        result = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
    else:
        # Jika grayscale, equalize langsung
        result = cv2.equalizeHist(image)
    
    if LOG_ENABLED:
        print("✓ Histogram equalization applied")
    
    return result


def create_collage(images, grid_size=COLLAGE_GRID_SIZE, padding=COLLAGE_PADDING, 
                   title=None, timestamps=None):
    """
    Buat collage dari beberapa gambar dalam grid
    
    Args:
        images (list): List gambar-gambar yang akan digabung
        grid_size (tuple): Ukuran grid (rows, cols)
        padding (int): Jarak antar gambar
        title (str): Judul collage (None = gunakan default)
        timestamps (list): List timestamp untuk setiap gambar (opsional)
        
    Returns:
        numpy.ndarray: Gambar collage
    """
    if not images or len(images) == 0:
        print("❌ Error: Tidak ada gambar untuk collage")
        return None
    
    rows, cols = grid_size
    required_images = rows * cols
    
    # Pastikan semua gambar memiliki ukuran yang sama
    target_h, target_w = CARD_HEIGHT, CARD_WIDTH
    processed_images = []
    
    for i, img in enumerate(images[:required_images]):
        if img is None:
            # Buat gambar placeholder jika None
            placeholder = np.zeros((target_h, target_w, 3), dtype=np.uint8)
            cv2.putText(placeholder, "No Image", (target_w//2 - 50, target_h//2),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (128, 128, 128), 2)
            processed_images.append(placeholder)
        else:
            # Resize ke ukuran target
            resized = resize_standard(img, target_w, target_h)
            
            # Tambahkan timestamp jika ada
            if timestamps and i < len(timestamps):
                time_text = timestamps[i]
                cv2.putText(resized, time_text, (10, target_h - 10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            
            processed_images.append(resized)
    
    # Jika kurang dari required_images, tambahkan placeholder
    while len(processed_images) < required_images:
        placeholder = np.zeros((target_h, target_w, 3), dtype=np.uint8)
        processed_images.append(placeholder)
    
    # Hitung ukuran total collage
    collage_h = rows * target_h + (rows + 1) * padding + COLLAGE_TITLE_HEIGHT
    collage_w = cols * target_w + (cols + 1) * padding
    
    # Buat canvas untuk collage
    collage = np.ones((collage_h, collage_w, 3), dtype=np.uint8) * 240  # Background abu-abu terang
    
    # Tambahkan title bar
    cv2.rectangle(collage, (0, 0), (collage_w, COLLAGE_TITLE_HEIGHT), 
                 COLLAGE_TITLE_BG_COLOR, -1)
    
    # Tambahkan title text
    if title is None:
        title = f"{COLLAGE_TITLE_TEXT}: {datetime.now().strftime('%Y-%m-%d')}"
    
    title_size = cv2.getTextSize(title, cv2.FONT_HERSHEY_SIMPLEX,
                                 COLLAGE_TITLE_FONT_SCALE, 2)[0]
    title_x = (collage_w - title_size[0]) // 2
    title_y = (COLLAGE_TITLE_HEIGHT + title_size[1]) // 2
    
    cv2.putText(collage, title, (title_x, title_y),
               cv2.FONT_HERSHEY_SIMPLEX, COLLAGE_TITLE_FONT_SCALE,
               COLLAGE_TITLE_COLOR, 2, cv2.LINE_AA)
    
    # Letakkan gambar-gambar ke grid
    idx = 0
    for row in range(rows):
        for col in range(cols):
            if idx < len(processed_images):
                img = processed_images[idx]
                
                # Hitung posisi
                y = COLLAGE_TITLE_HEIGHT + (row + 1) * padding + row * target_h
                x = (col + 1) * padding + col * target_w
                
                # Paste gambar
                collage[y:y+target_h, x:x+target_w] = img
                
                # Tambahkan border untuk setiap gambar
                cv2.rectangle(collage, (x-1, y-1), (x+target_w, y+target_h),
                            (100, 100, 100), 2)
                
                # Tambahkan label
                label = f"Card #{idx+1}"
                cv2.putText(collage, label, (x+5, y+20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                
                idx += 1
    
    if LOG_ENABLED:
        print(f"✓ Collage dibuat: {rows}x{cols} grid, total {idx} gambar")
    
    return collage


# ===== TESTING =====
if __name__ == "__main__":
    print("=== TESTING PROCESS MODULE ===\n")
    
    # Buat gambar test
    test_img = np.ones((500, 800, 3), dtype=np.uint8) * 150
    cv2.rectangle(test_img, (50, 50), (750, 450), (0, 255, 0), 3)
    cv2.putText(test_img, "TEST CARD", (250, 250),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    
    print("Test 1: Resize")
    resized = resize_standard(test_img)
    print(f"Original: {test_img.shape}, Resized: {resized.shape}")
    
    print("\nTest 2: Add timestamp")
    with_timestamp = add_timestamp(resized)
    
    print("\nTest 3: Add watermark")
    with_watermark = add_watermark(with_timestamp)
    
    print("\nTest 4: Add border")
    final = add_border(with_watermark)
    
    cv2.imshow("Original", test_img)
    cv2.imshow("Processed", final)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
    print("\nTest 5: Create collage")
    test_images = [final, final, final, final]
    collage = create_collage(test_images, timestamps=["08:30:45", "09:15:22", "10:00:15", "11:45:33"])
    
    if collage is not None:
        cv2.imshow("Collage", collage)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
