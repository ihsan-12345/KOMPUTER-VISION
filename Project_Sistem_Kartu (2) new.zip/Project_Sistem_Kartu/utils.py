# utils.py
# Fungsi utilitas untuk Sistem Kartu

import cv2
import os
from datetime import datetime
from config import *

# ============================================================
# KOMENTAR VIDEO (alur penjelasan utilitas)
# 1) Modul ini untuk operasi pendukung: simpan file, statistik, menu CLI, validasi input.
# 2) Tunjukkan penyimpanan terorganisir otomatis berdasarkan tanggal.
# 3) Jelaskan fungsi helper interaksi user: `confirm_action` dan `get_user_input`.
# 4) Bahas statistik ringkas untuk monitoring progres pemrosesan.
# 5) Tekankan bahwa modul utilitas bikin `main.py` tetap bersih dan modular.
# ============================================================

def save_with_organization(image, filename=None, subfolder=None):
    """
    Simpan gambar dengan organisasi folder berdasarkan tanggal
    
    Args:
        image (numpy.ndarray): Gambar yang akan disimpan
        filename (str): Nama file (None = generate otomatis)
        subfolder (str): Subfolder tambahan (None = gunakan tanggal)
        
    Returns:
        str: Path lengkap file yang tersimpan, atau None jika gagal
    """
    if image is None:
        print("❌ Error: Gambar None, tidak dapat disimpan")
        return None
    
    # Generate filename jika tidak diberikan
    if filename is None:
        filename = datetime.now().strftime(OUTPUT_FILENAME_FORMAT) + f".{OUTPUT_FORMAT}"
    
    # Tentukan subfolder
    if subfolder is None:
        subfolder = datetime.now().strftime("%Y-%m-%d")
    
    # Buat path lengkap
    output_dir = os.path.join(OUTPUT_FOLDER, subfolder)
    
    # Buat folder jika belum ada
    os.makedirs(output_dir, exist_ok=True)
    
    # Path lengkap file
    filepath = os.path.join(output_dir, filename)
    
    # Simpan gambar
    try:
        success = cv2.imwrite(filepath, image, [cv2.IMWRITE_JPEG_QUALITY, OUTPUT_QUALITY])
        
        if success:
            if LOG_ENABLED:
                print(f"✓ Gambar disimpan: {filepath}")
                print(f"  Ukuran file: {os.path.getsize(filepath):,} bytes")
            return filepath
        else:
            print(f"❌ Error: Gagal menyimpan gambar ke {filepath}")
            return None
            
    except Exception as e:
        print(f"❌ Error saat menyimpan gambar: {e}")
        return None


def save_collage(collage, filename=None):
    """
    Simpan collage ke folder khusus collages
    
    Args:
        collage (numpy.ndarray): Gambar collage
        filename (str): Nama file (None = generate otomatis)
        
    Returns:
        str: Path lengkap file yang tersimpan, atau None jika gagal
    """
    if collage is None:
        print("❌ Error: Collage None, tidak dapat disimpan")
        return None
    
    # Generate filename jika tidak diberikan
    if filename is None:
        filename = datetime.now().strftime(COLLAGE_FILENAME_FORMAT) + f".{OUTPUT_FORMAT}"
    
    # Pastikan folder collages ada
    os.makedirs(COLLAGE_FOLDER, exist_ok=True)
    
    # Path lengkap
    filepath = os.path.join(COLLAGE_FOLDER, filename)
    
    # Simpan collage
    try:
        success = cv2.imwrite(filepath, collage, [cv2.IMWRITE_JPEG_QUALITY, OUTPUT_QUALITY])
        
        if success:
            if LOG_ENABLED:
                print(f"✓ Collage disimpan: {filepath}")
                print(f"  Ukuran file: {os.path.getsize(filepath):,} bytes")
            return filepath
        else:
            print(f"❌ Error: Gagal menyimpan collage ke {filepath}")
            return None
            
    except Exception as e:
        print(f"❌ Error saat menyimpan collage: {e}")
        return None


def ensure_directories():
    """
    Pastikan semua direktori yang diperlukan ada
    """
    directories = [
        INPUT_FOLDER,
        OUTPUT_FOLDER,
        COLLAGE_FOLDER
    ]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)
            print(f"✓ Folder dibuat: {directory}")
        else:
            if LOG_ENABLED:
                print(f"✓ Folder sudah ada: {directory}")


def get_files_in_folder(folder, extension=None):
    """
    Dapatkan daftar file dalam folder
    
    Args:
        folder (str): Path folder
        extension (str): Filter ekstensi (None = semua file)
        
    Returns:
        list: List path file lengkap
    """
    if not os.path.exists(folder):
        print(f"❌ Error: Folder tidak ditemukan - {folder}")
        return []
    
    files = []
    for filename in os.listdir(folder):
        filepath = os.path.join(folder, filename)
        
        if os.path.isfile(filepath):
            if extension is None or filename.lower().endswith(extension.lower()):
                files.append(filepath)
    
    return files


def get_processed_count(date_str=None):
    """
    Hitung jumlah gambar yang telah diproses pada tanggal tertentu
    
    Args:
        date_str (str): String tanggal (YYYY-MM-DD), None = hari ini
        
    Returns:
        int: Jumlah file
    """
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    folder = os.path.join(OUTPUT_FOLDER, date_str)
    
    if not os.path.exists(folder):
        return 0
    
    files = [f for f in os.listdir(folder) if os.path.isfile(os.path.join(folder, f))]
    return len(files)


def clear_terminal():
    """
    Clear terminal screen (cross-platform)
    """
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception:
        # Jika clear gagal, print newlines aja
        print('\n' * 50)


def print_banner():
    """
    Print banner aplikasi
    """
    banner = """
╔══════════════════════════════════════════════════════════╗
║                                                          ║
║              🎓 SMARTATTEND SYSTEM v1.0 🎓               ║
║                                                          ║
║        Sistem Pencatat Kehadiran Digital                ║
║           Berbasis Kartu Identitas                       ║
║                                                          ║
╚══════════════════════════════════════════════════════════╝
    """
    print(banner)


def print_menu():
    """
    Print menu utama
    """
    menu = """
┌──────────────────────────────────────────┐
│              MENU UTAMA                  │
├──────────────────────────────────────────┤
│  1. Process Single Image                 │
│  2. Process Multiple Images              │
│  3. Capture from Webcam                  │
│  4. Create Collage                       │
│  5. View Statistics                      │
├──────────────────────────────────────────┤
│        FITUR BONUS & ADVANCED 🆕        │
├──────────────────────────────────────────┤
│  7. Image Quality Check          ✨      │
│  8. Auto Enhancement             ✨      │
│  9. Duplicate Detection          ✨      │
│  10. Export Report               ✨      │
├──────────────────────────────────────────┤
│  6. Settings                             │
│  0. Exit                                 │
└──────────────────────────────────────────┘
    """
    print(menu)


def print_separator(char='=', length=60):
    """
    Print separator line
    """
    print(char * length)


def format_file_size(size_bytes):
    """
    Format ukuran file menjadi string yang mudah dibaca
    
    Args:
        size_bytes (int): Ukuran dalam bytes
        
    Returns:
        str: String formatted (e.g., "1.5 MB")
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} TB"


def show_statistics():
    """
    Tampilkan statistik pemrosesan
    """
    print("\n" + "="*60)
    print("                    STATISTIK SISTEM")
    print("="*60)
    
    # Hitung file hari ini
    today = datetime.now().strftime("%Y-%m-%d")
    today_count = get_processed_count(today)
    
    print(f"\n📅 Tanggal: {today}")
    print(f"📊 Kartu diproses hari ini: {today_count}")
    
    # Hitung total file di folder output
    total_files = 0
    total_size = 0
    
    if os.path.exists(OUTPUT_FOLDER):
        for root, dirs, files in os.walk(OUTPUT_FOLDER):
            for file in files:
                if file.endswith(('.jpg', '.jpeg', '.png')):
                    filepath = os.path.join(root, file)
                    total_files += 1
                    total_size += os.path.getsize(filepath)
    
    print(f"📈 Total kartu tersimpan: {total_files}")
    print(f"💾 Total ukuran storage: {format_file_size(total_size)}")
    
    # Hitung collages
    collage_count = 0
    if os.path.exists(COLLAGE_FOLDER):
        collage_count = len([f for f in os.listdir(COLLAGE_FOLDER) 
                            if f.endswith(('.jpg', '.jpeg', '.png'))])
    
    print(f"🖼️  Total collages: {collage_count}")
    
    print("="*60 + "\n")


def confirm_action(message="Lanjutkan?", default=True):
    """
    Konfirmasi aksi dari user
    
    Args:
        message (str): Pesan konfirmasi
        default (bool): Default value
        
    Returns:
        bool: True jika user konfirmasi
    """
    prompt = f"{message} [{'Y/n' if default else 'y/N'}]: "
    response = input(prompt).strip().lower()
    
    if not response:
        return default
    
    return response in ['y', 'yes', 'ya']


def get_user_input(prompt, input_type=str, default=None, valid_range=None):
    """
    Dapatkan input dari user dengan validasi
    
    Args:
        prompt (str): Prompt message
        input_type (type): Tipe data yang diharapkan
        default: Nilai default jika user tidak input
        valid_range (tuple): Range valid untuk angka (min, max)
        
    Returns:
        Input yang telah divalidasi
    """
    while True:
        try:
            user_input = input(f"{prompt}: ").strip()
            
            if not user_input and default is not None:
                return default
            
            # Konversi ke tipe yang diinginkan
            value = input_type(user_input)
            
            # Validasi range untuk angka
            if valid_range and isinstance(value, (int, float)):
                if not (valid_range[0] <= value <= valid_range[1]):
                    print(f"❌ Nilai harus antara {valid_range[0]} dan {valid_range[1]}")
                    continue
            
            return value
            
        except ValueError:
            print(f"❌ Input tidak valid. Harap masukkan {input_type.__name__}")
        except KeyboardInterrupt:
            print("\n❌ Input dibatalkan")
            return default


# ===== TESTING =====
if __name__ == "__main__":
    print("=== TESTING UTILS MODULE ===\n")
    
    # Test 1: Ensure directories
    print("Test 1: Ensure directories")
    ensure_directories()
    
    # Test 2: Print banner dan menu
    print("\nTest 2: Banner dan Menu")
    clear_terminal()
    print_banner()
    print_menu()
    
    # Test 3: Statistics
    print("\nTest 3: Statistics")
    show_statistics()
    
    # Test 4: File operations
    print("\nTest 4: File operations")
    print(f"Files in input folder: {len(get_files_in_folder(INPUT_FOLDER))}")
    print(f"Processed today: {get_processed_count()}")
    
    # Test 5: Format file size
    print("\nTest 5: Format file size")
    print(f"1024 bytes = {format_file_size(1024)}")
    print(f"1048576 bytes = {format_file_size(1048576)}")
    print(f"1073741824 bytes = {format_file_size(1073741824)}")
