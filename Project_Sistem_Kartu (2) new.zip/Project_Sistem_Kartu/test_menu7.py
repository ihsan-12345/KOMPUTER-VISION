# test_menu7.py
# Simple test untuk menu 7

import sys
import os

print("Testing Menu 7: Image Quality Check")
print("="*60)

try:
    print("\n1. Importing modules...")
    from enhancement_module import *
    from capture_module import load_image
    print("   ✅ Imports OK")
    
    print("\n2. Creating test image...")
    import numpy as np
    import cv2
    
    # Buat test image
    test_img = np.ones((400, 600, 3), dtype=np.uint8) * 150
    cv2.rectangle(test_img, (50, 50), (550, 350), (0, 255, 0), 3)
    cv2.putText(test_img, "TEST CARD", (200, 200),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    
    # Save test image
    os.makedirs('input', exist_ok=True)
    cv2.imwrite('input/test_ktm.jpg', test_img)
    print("   ✅ Test image created and saved to input/test_ktm.jpg")
    
    print("\n3. Testing quality check...")
    is_valid, score, message = check_image_quality(test_img)
    print(f"   ✅ Quality check: {message}")
    print(f"      Score: {score}/100")
    
    print("\n4. Testing orientation detection...")
    orientation = detect_card_orientation(test_img)
    print(f"   ✅ Orientation: {orientation['orientation']}")
    print(f"      Aspect ratio: {orientation['aspect_ratio']:.2f}")
    
    print("\n5. Testing face detection...")
    faces = detect_face(test_img)
    print(f"   ✅ Faces detected: {len(faces)}")
    
    print("\n6. Testing display report...")
    display_quality_report(test_img)
    
    print("="*60)
    print("✅ ALL MENU 7 FEATURES WORKING!")
    print("="*60)
    
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
