# enhancement_module.py
# Modul tambahan untuk fitur bonus dan enhancement

import cv2
import numpy as np
from datetime import datetime
import os
from config import *

# ============================================================
# KOMENTAR VIDEO (alur penjelasan fitur enhancement)
# 1) Modul ini berisi fitur bonus: quality scoring, enhancement, face detection, report.
# 2) Jelaskan deteksi wajah dengan Haar Cascade + preprocessing multi-pass.
# 3) Tunjukkan quality metrics: blur, brightness, contrast, lalu overall score.
# 4) Bahas auto-enhance (histogram eq + CLAHE) untuk memperbaiki kartu yang kurang jelas.
# 5) Tutup dengan duplicate detection dan export statistik JSON/CSV.
# ============================================================

# ===== FACE DETECTION =====

def detect_face(image):
    """
    Deteksi wajah dalam gambar menggunakan Haar Cascade
    
    Args:
        image (numpy.ndarray): Gambar input
        
    Returns:
        list: List of (x, y, w, h) untuk setiap wajah yang terdeteksi
    """
    if image is None:
        return []
    
    # Load haar cascade untuk face detection
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
    )
    
    # Konversi ke grayscale jika perlu
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image

    # Preprocess untuk meningkatkan deteksi wajah kecil pada kartu
    gray_eq = cv2.equalizeHist(gray)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray_clahe = clahe.apply(gray)

    # Multi-pass detection: normal + lebih sensitif untuk wajah kecil
    detection_passes = [
        (gray, 1.1, 5, (30, 30)),
        (gray_eq, 1.08, 4, (20, 20)),
        (gray_clahe, 1.05, 3, (16, 16)),
    ]

    faces = []
    for scan_img, scale_factor, min_neighbors, min_size in detection_passes:
        current_faces = face_cascade.detectMultiScale(
            scan_img,
            scaleFactor=scale_factor,
            minNeighbors=min_neighbors,
            minSize=min_size,
            flags=cv2.CASCADE_SCALE_IMAGE
        )

        if len(current_faces) > 0:
            faces = current_faces
            break

    # Fallback: upscaling untuk wajah yang sangat kecil di kartu
    if len(faces) == 0:
        h, w = gray.shape[:2]
        upscaled = cv2.resize(gray_clahe, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC)
        upscaled_faces = face_cascade.detectMultiScale(
            upscaled,
            scaleFactor=1.05,
            minNeighbors=3,
            minSize=(24, 24),
            flags=cv2.CASCADE_SCALE_IMAGE
        )

        if len(upscaled_faces) > 0:
            faces = [(x // 2, y // 2, fw // 2, fh // 2) for (x, y, fw, fh) in upscaled_faces]
    
    if LOG_ENABLED and len(faces) > 0:
        print(f"✓ Terdeteksi {len(faces)} wajah")
    
    return faces


def draw_face_rectangles(image, faces, color=(0, 255, 0), thickness=2):
    """
    Gambar rectangle di sekitar wajah yang terdeteksi
    
    Args:
        image (numpy.ndarray): Gambar input
        faces (list): List of (x, y, w, h)
        color (tuple): Warna rectangle (BGR)
        thickness (int): Ketebalan garis
        
    Returns:
        numpy.ndarray: Gambar dengan rectangle
    """
    if image is None or len(faces) == 0:
        return image
    
    result = image.copy()
    
    for (x, y, w, h) in faces:
        cv2.rectangle(result, (x, y), (x+w, y+h), color, thickness)
        # Tambahkan label
        cv2.putText(result, "Face Detected", (x, y-10),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    
    return result


# ===== IMAGE QUALITY CHECK =====

def calculate_image_quality_score(image):
    """
    Hitung score kualitas gambar (0-100)
    
    Args:
        image (numpy.ndarray): Gambar input
        
    Returns:
        dict: Dictionary berisi quality metrics
    """
    if image is None:
        return None
    
    # Convert to grayscale
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image
    
    results = {
        'overall_score': 0,
        'blur_score': 0,
        'brightness_score': 0,
        'contrast_score': 0,
        'details': {}
    }
    
    # 1. Blur Detection (Laplacian Variance)
    laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
    blur_score = min(100, int((laplacian_var / 100) * 100))  # Normalize
    results['blur_score'] = blur_score
    results['details']['blur'] = f"{blur_score}% - {'Sharp' if blur_score > 50 else 'Blurry'}"
    
    # 2. Brightness Check
    brightness = np.mean(gray)
    if 70 < brightness < 180:
        brightness_score = 100
    elif 50 < brightness < 200:
        brightness_score = 80
    elif 30 < brightness < 220:
        brightness_score = 60
    else:
        brightness_score = 30
    
    results['brightness_score'] = brightness_score
    results['details']['brightness'] = f"{brightness_score}% - Level: {int(brightness)}"
    
    # 3. Contrast Check (Standard Deviation)
    contrast = np.std(gray)
    if contrast > 50:
        contrast_score = 100
    elif contrast > 30:
        contrast_score = 80
    elif contrast > 15:
        contrast_score = 60
    else:
        contrast_score = 30
    
    results['contrast_score'] = contrast_score
    results['details']['contrast'] = f"{contrast_score}% - Std Dev: {int(contrast)}"
    
    # Overall score (weighted average)
    overall = (blur_score * 0.5 + brightness_score * 0.25 + contrast_score * 0.25)
    results['overall_score'] = int(overall)
    
    if LOG_ENABLED:
        print(f"✓ Image Quality Score: {results['overall_score']}/100")
    
    return results


def check_image_quality(image, min_score=60):
    """
    Check apakah gambar memenuhi minimum quality
    
    Args:
        image (numpy.ndarray): Gambar input
        min_score (int): Minimum score yang diizinkan (0-100)
        
    Returns:
        tuple: (is_valid, score, message)
    """
    scores = calculate_image_quality_score(image)
    
    if scores is None:
        return False, 0, "Image is None"
    
    score = scores['overall_score']
    is_valid = score >= min_score
    
    if is_valid:
        message = f"✅ Quality OK ({score}/100)"
    else:
        message = f"⚠️  Quality LOW ({score}/100) - Min required: {min_score}"
    
    return is_valid, score, message


def display_quality_report(image, title="Image Quality Report"):
    """
    Tampilkan quality report ke console
    
    Args:
        image (numpy.ndarray): Gambar input
        title (str): Judul laporan
    """
    scores = calculate_image_quality_score(image)
    
    if scores is None:
        print("❌ Cannot compute quality score")
        return
    
    print(f"\n{'='*50}")
    print(f"  {title}")
    print(f"{'='*50}")
    print(f"  Overall Score: {scores['overall_score']}/100")
    print(f"  ")
    for metric, value in scores['details'].items():
        print(f"  {metric.capitalize()}: {value}")
    print(f"{'='*50}\n")


# ===== AUTO ENHANCEMENT =====

def auto_enhance_image(image, apply_histogram_eq=True, apply_clahe=True):
    """
    Otomatis enhance gambar berdasarkan kualitasnya
    
    Args:
        image (numpy.ndarray): Gambar input
        apply_histogram_eq (bool): Apply histogram equalization
        apply_clahe (bool): Apply Contrast Limited Adaptive Histogram Equalization
        
    Returns:
        numpy.ndarray: Gambar yang di-enhance
    """
    if image is None:
        return None
    
    result = image.copy()
    
    # Konversi ke HSV untuk enhancement yang lebih baik
    if len(result.shape) == 3 and result.shape[2] == 3:
        hsv = cv2.cvtColor(result, cv2.COLOR_BGR2HSV)
        
        if apply_histogram_eq:
            # Apply histogram equalization pada Value channel
            hsv[:, :, 2] = cv2.equalizeHist(hsv[:, :, 2])
        
        if apply_clahe:
            # Apply CLAHE
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            hsv[:, :, 2] = clahe.apply(hsv[:, :, 2])
        
        result = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
    else:
        # Grayscale image
        if apply_histogram_eq:
            result = cv2.equalizeHist(result)
        
        if apply_clahe:
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
            result = clahe.apply(result)
    
    if LOG_ENABLED:
        print("✓ Auto enhancement applied")
    
    return result


# ===== ROTATION DETECTION =====

def detect_card_orientation(image):
    """
    Deteksi orientasi kartu (portrait/landscape)
    
    Args:
        image (numpy.ndarray): Gambar input
        
    Returns:
        dict: Berisi orientation info
    """
    if image is None:
        return None
    
    h, w = image.shape[:2]
    aspect_ratio = w / h
    
    if aspect_ratio > 1.2:
        orientation = "LANDSCAPE"
        confidence = "HIGH" if aspect_ratio > 1.5 else "MEDIUM"
    elif aspect_ratio < 0.85:
        orientation = "PORTRAIT"
        confidence = "HIGH" if aspect_ratio < 0.65 else "MEDIUM"
    else:
        orientation = "SQUARE"
        confidence = "MEDIUM"
    
    result = {
        'orientation': orientation,
        'aspect_ratio': aspect_ratio,
        'confidence': confidence,
        'width': w,
        'height': h
    }
    
    if LOG_ENABLED:
        print(f"✓ Detected orientation: {orientation} ({aspect_ratio:.2f})")
    
    return result


# ===== COMPARISON =====

def calculate_image_similarity(image1, image2):
    """
    Hitung similarity score antara 2 gambar menggunakan histogram comparison
    
    Args:
        image1, image2 (numpy.ndarray): Gambar yang dibandingkan
        
    Returns:
        float: Similarity score (0-1)
    """
    if image1 is None or image2 is None:
        return 0.0
    
    # Resize ke ukuran yang sama untuk comparison
    target_size = (100, 100)
    img1_resized = cv2.resize(image1, target_size)
    img2_resized = cv2.resize(image2, target_size)
    
    # Konversi ke grayscale
    if len(img1_resized.shape) == 3:
        img1_gray = cv2.cvtColor(img1_resized, cv2.COLOR_BGR2GRAY)
    else:
        img1_gray = img1_resized
    
    if len(img2_resized.shape) == 3:
        img2_gray = cv2.cvtColor(img2_resized, cv2.COLOR_BGR2GRAY)
    else:
        img2_gray = img2_resized
    
    # Hitung histogram
    hist1 = cv2.calcHist([img1_gray], [0], None, [256], [0, 256])
    hist2 = cv2.calcHist([img2_gray], [0], None, [256], [0, 256])
    
    # Normalize
    hist1 = cv2.normalize(hist1, hist1).flatten()
    hist2 = cv2.normalize(hist2, hist2).flatten()
    
    # Compare
    similarity = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
    
    # Convert to score (0-1, higher is more similar)
    score = 1 - similarity
    
    return max(0.0, min(1.0, score))


def find_duplicate_images(image_list, threshold=0.95):
    """
    Temukan gambar duplikat dalam list
    
    Args:
        image_list (list): List of (filename, image) tuples
        threshold (float): Similarity threshold (0-1)
        
    Returns:
        list: List of duplicate groups
    """
    duplicates = []
    checked = set()
    
    for i, (name1, img1) in enumerate(image_list):
        if i in checked:
            continue
        
        duplicate_group = [name1]
        
        for j, (name2, img2) in enumerate(image_list[i+1:], start=i+1):
            if j in checked:
                continue
            
            similarity = calculate_image_similarity(img1, img2)
            
            if similarity >= threshold:
                duplicate_group.append(name2)
                checked.add(j)
        
        if len(duplicate_group) > 1:
            duplicates.append(duplicate_group)
    
    return duplicates


# ===== BATCH OPERATIONS =====

def batch_auto_enhance(image_list):
    """
    Apply auto enhance ke multiple gambar
    
    Args:
        image_list (list): List of (filename, image) tuples
        
    Returns:
        list: List of enhanced images
    """
    enhanced = []
    
    for filename, image in image_list:
        enhanced_img = auto_enhance_image(image)
        enhanced.append((filename, enhanced_img))
    
    return enhanced


def apply_quality_filter(image_list, min_score=60):
    """
    Filter gambar berdasarkan quality score
    
    Args:
        image_list (list): List of (filename, image) tuples
        min_score (int): Minimum quality score
        
    Returns:
        tuple: (passed, rejected) - list of tuples
    """
    passed = []
    rejected = []
    
    for filename, image in image_list:
        is_valid, score, message = check_image_quality(image, min_score)
        
        if is_valid:
            passed.append((filename, image, score))
        else:
            rejected.append((filename, image, score))
    
    return passed, rejected


# ===== EXPORT REPORT =====

def export_statistics_report(output_folder, format='json', destination=None):
    """
    Export statistik ke file JSON atau CSV
    
    Args:
        output_folder (str): Folder dengan hasil
        format (str): Format output ('json' atau 'csv')
        destination (str): Path file destination (None = auto-generate)
        
    Returns:
        str: Path ke file yang diexport
    """
    import json
    
    if not os.path.exists(output_folder):
        print(f"❌ Folder tidak ditemukan: {output_folder}")
        return None
    
    stats = {
        'generated_at': datetime.now().isoformat(),
        'folder': output_folder,
        'files': [],
        'summary': {
            'total_files': 0,
            'total_size_bytes': 0,
            'average_quality': 0
        }
    }
    
    quality_scores = []
    
    # Collect file info
    for root, dirs, files in os.walk(output_folder):
        for file in files:
            if file.endswith(('.jpg', '.jpeg', '.png')):
                filepath = os.path.join(root, file)
                filesize = os.path.getsize(filepath)
                
                # Try to compute quality
                img = cv2.imread(filepath)
                quality = 0
                if img is not None:
                    scores = calculate_image_quality_score(img)
                    quality = scores['overall_score'] if scores else 0
                    quality_scores.append(quality)
                
                stats['files'].append({
                    'filename': file,
                    'path': filepath,
                    'size_bytes': filesize,
                    'quality_score': quality
                })
                
                stats['summary']['total_files'] += 1
                stats['summary']['total_size_bytes'] += filesize
    
    if quality_scores:
        stats['summary']['average_quality'] = int(np.mean(quality_scores))
    
    # Generate destination if not provided
    if destination is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = os.path.join(output_folder, f"report_{timestamp}.{format}")
    
    # Export
    if format.lower() == 'json':
        with open(destination, 'w') as f:
            json.dump(stats, f, indent=2)
    
    elif format.lower() == 'csv':
        import csv
        with open(destination, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Filename', 'Size (bytes)', 'Quality Score'])
            for file_info in stats['files']:
                writer.writerow([
                    file_info['filename'],
                    file_info['size_bytes'],
                    file_info['quality_score']
                ])
    
    if LOG_ENABLED:
        print(f"✓ Report exported: {destination}")
        print(f"  Total files: {stats['summary']['total_files']}")
        print(f"  Total size: {stats['summary']['total_size_bytes']:,} bytes")
        print(f"  Average quality: {stats['summary']['average_quality']}/100")
    
    return destination


# ===== TESTING =====
if __name__ == "__main__":
    print("=== TESTING ENHANCEMENT MODULE ===\n")
    
    # Create test image
    test_img = np.ones((400, 600, 3), dtype=np.uint8) * 150
    cv2.rectangle(test_img, (50, 50), (550, 350), (0, 255, 0), 3)
    cv2.putText(test_img, "TEST CARD", (200, 200),
                cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    
    print("Test 1: Image Quality Check")
    display_quality_report(test_img, "Test Image Quality")
    
    print("Test 2: Card Orientation Detection")
    orientation = detect_card_orientation(test_img)
    print(f"  Orientation: {orientation['orientation']}")
    print(f"  Aspect Ratio: {orientation['aspect_ratio']:.2f}")
    
    print("\nTest 3: Face Detection")
    faces = detect_face(test_img)
    print(f"  Faces detected: {len(faces)}")
    
    print("\nTest 4: Auto Enhancement")
    enhanced = auto_enhance_image(test_img)
    print(f"  Enhancement applied")
    
    print("\nTest 5: Image Similarity")
    test_img2 = test_img.copy()
    similarity = calculate_image_similarity(test_img, test_img2)
    print(f"  Similarity score: {similarity:.2f} (should be ~1.0)")
    
    print("\n✅ All tests completed!")
