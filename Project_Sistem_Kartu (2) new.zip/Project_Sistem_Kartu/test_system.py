# test_system.py
# Script untuk testing sistem SmartAttend

import cv2
import numpy as np
import os
from datetime import datetime

# Import modul-modul
from config import *
from capture_module import *
from process_module import *
from utils import *

def create_sample_card_image(text, filename, width=600, height=400):
    """
    Buat gambar kartu sample untuk testing
    """
    # Buat canvas putih
    img = np.ones((height, width, 3), dtype=np.uint8) * 255
    
    # Tambahkan background warna
    cv2.rectangle(img, (0, 0), (width, 100), (52, 152, 219), -1)  # Header biru
    cv2.rectangle(img, (0, height-80), (width, height), (52, 152, 219), -1)  # Footer biru
    
    # Tambahkan border
    cv2.rectangle(img, (10, 10), (width-10, height-10), (41, 128, 185), 3)
    
    # Tambahkan logo/icon (lingkaran dengan initial)
    cv2.circle(img, (100, 50), 30, (255, 255, 255), -1)
    cv2.putText(img, text[0], (88, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (52, 152, 219), 3)
    
    # Tambahkan text header
    cv2.putText(img, "KARTU IDENTITAS", (150, 60), 
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    
    # Tambahkan foto placeholder
    cv2.rectangle(img, (30, 120), (180, 320), (200, 200, 200), -1)
    cv2.putText(img, "FOTO", (70, 230), 
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (150, 150, 150), 2)
    
    # Tambahkan informasi
    info_x = 200
    info_y_start = 140
    line_height = 35
    
    info_lines = [
        f"Nama: {text}",
        f"NIM: {np.random.randint(100000, 999999)}",
        "Program Studi: Informatika",
        "Fakultas: Teknik",
        f"Tahun: {datetime.now().year}",
    ]
    
    for i, line in enumerate(info_lines):
        y = info_y_start + i * line_height
        cv2.putText(img, line, (info_x, y), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (50, 50, 50), 1)
    
    # Tambahkan footer text
    cv2.putText(img, "UNIVERSITAS SAMPLE", (150, height-40), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    
    # Tambahkan barcode placeholder
    cv2.rectangle(img, (width-150, height-70), (width-20, height-20), (0, 0, 0), -1)
    
    # Simpan
    filepath = os.path.join(INPUT_FOLDER, filename)
    cv2.imwrite(filepath, img)
    print(f"✓ Sample card created: {filepath}")
    
    return img


def test_all_modules():
    """
    Test semua modul sistem
    """
    print("="*70)
    print("          TEST SUITE - SMARTATTEND SYSTEM")
    print("="*70)
    
    # Ensure directories exist
    ensure_directories()
    
    # Test 1: Create sample images
    print("\n[TEST 1] Creating sample card images...")
    print("-"*70)
    
    sample_names = [
        "Ahmad Pratama",
        "Siti Nurhaliza",
        "Budi Santoso",
        "Dewi Lestari",
        "Rizki Ramadhan"
    ]
    
    sample_images = []
    for i, name in enumerate(sample_names, 1):
        img = create_sample_card_image(name, f"sample_kartu_{i}.jpg")
        sample_images.append(img)
    
    print(f"✅ Created {len(sample_images)} sample cards")
    
    # Test 2: Load images
    print("\n[TEST 2] Testing load_image()...")
    print("-"*70)
    
    loaded_images = load_multiple_images(INPUT_FOLDER)
    print(f"✅ Loaded {len(loaded_images)} images")
    
    # Test 3: Process single image
    print("\n[TEST 3] Testing process pipeline...")
    print("-"*70)
    
    if loaded_images:
        test_img = loaded_images[0][1]
        
        # Process
        processed = resize_standard(test_img)
        processed = adjust_brightness_contrast(processed, brightness=10, contrast=1.1)
        processed = add_timestamp(processed)
        processed = add_watermark(processed)
        processed = add_border(processed)
        
        # Save
        filepath = save_with_organization(processed)
        print(f"✅ Processed and saved: {filepath}")
    
    # Test 4: Batch processing
    print("\n[TEST 4] Testing batch processing...")
    print("-"*70)
    
    processed_images = []
    for filename, img in loaded_images[:4]:
        processed = resize_standard(img)
        processed = add_timestamp(processed)
        processed = add_watermark(processed)
        processed = add_border(processed)
        processed_images.append(processed)
        save_with_organization(processed)
    
    print(f"✅ Batch processed {len(processed_images)} images")
    
    # Test 5: Create collage
    print("\n[TEST 5] Testing collage creation...")
    print("-"*70)
    
    if len(processed_images) >= 4:
        collage = create_collage(processed_images[:4], 
                                timestamps=["08:30", "09:15", "10:00", "11:45"])
        
        if collage is not None:
            filepath = save_collage(collage)
            print(f"✅ Collage created and saved: {filepath}")
    
    # Test 6: Statistics
    print("\n[TEST 6] Testing statistics...")
    print("-"*70)
    show_statistics()
    
    # Test 7: Grayscale conversion
    print("\n[TEST 7] Testing grayscale conversion...")
    print("-"*70)
    
    if loaded_images:
        test_img = loaded_images[0][1]
        gray = convert_to_grayscale(test_img)
        
        gray_resized = resize_standard(gray)
        # Convert back to BGR for saving
        gray_bgr = cv2.cvtColor(gray_resized, cv2.COLOR_GRAY2BGR)
        gray_bgr = add_timestamp(gray_bgr)
        gray_bgr = add_watermark(gray_bgr)
        save_with_organization(gray_bgr, filename="grayscale_test.jpg")
        print("✅ Grayscale conversion successful")
    
    # Test 8: Histogram equalization
    print("\n[TEST 8] Testing histogram equalization...")
    print("-"*70)
    
    if loaded_images:
        test_img = loaded_images[0][1]
        # Darken image untuk test
        dark_img = adjust_brightness_contrast(test_img, brightness=-50, contrast=0.5)
        equalized = histogram_equalization(dark_img)
        
        equalized = resize_standard(equalized)
        equalized = add_timestamp(equalized)
        equalized = add_watermark(equalized)
        save_with_organization(equalized, filename="histogram_eq_test.jpg")
        print("✅ Histogram equalization successful")
    
    # Summary
    print("\n" + "="*70)
    print("                    TEST SUMMARY")
    print("="*70)
    print("✅ All tests completed successfully!")
    print("\nGenerated files:")
    print(f"  - Input folder: {INPUT_FOLDER}")
    print(f"  - Output folder: {OUTPUT_FOLDER}")
    print(f"  - Collage folder: {COLLAGE_FOLDER}")
    print("\nYou can now run: python main.py")
    print("="*70)


def demo_visual():
    """
    Demo visual untuk menampilkan hasil
    """
    print("\n[VISUAL DEMO] Displaying results...")
    print("Press any key to see next image, ESC to exit")
    
    # Load sample
    images = load_multiple_images(INPUT_FOLDER, max_images=1)
    if not images:
        print("❌ No images found for demo")
        return
    
    original = images[0][1]
    
    # Create processed versions
    stages = {
        "1. Original": original,
        "2. Resized": resize_standard(original),
    }
    
    resized = resize_standard(original)
    stages["3. With Timestamp"] = add_timestamp(resized.copy())
    stages["4. With Watermark"] = add_watermark(stages["3. With Timestamp"].copy())
    stages["5. Final (with Border)"] = add_border(stages["4. With Watermark"].copy())
    
    # Display each stage
    for title, img in stages.items():
        cv2.imshow(f"Demo: {title}", img)
        key = cv2.waitKey(0)
        if key == 27:  # ESC
            break
        cv2.destroyAllWindows()
    
    cv2.destroyAllWindows()
    print("✅ Visual demo completed")


if __name__ == "__main__":
    import sys
    
    print("\n🚀 SmartAttend System - Test Suite\n")
    
    if len(sys.argv) > 1 and sys.argv[1] == "--visual":
        # Visual demo mode
        demo_visual()
    else:
        # Full test mode
        test_all_modules()
        
        # Ask if want visual demo
        print("\n" + "="*70)
        response = input("Run visual demo? (y/n): ").strip().lower()
        if response == 'y':
            demo_visual()
    
    print("\n✅ Testing complete!")
