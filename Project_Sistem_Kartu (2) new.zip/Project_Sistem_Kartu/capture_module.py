# capture_module.py
# Modul untuk capture dan loading gambar kartu identitas

import cv2
import numpy as np
import os
from config import *

# ============================================================
# KOMENTAR VIDEO (alur penjelasan modul capture)
# 1) Modul ini fokus ke input data: load file lokal dan capture webcam.
# 2) Jelaskan validasi awal: cek file ada dan ekstensi didukung.
# 3) Tunjukkan alur webcam real-time + tombol SPACE/ESC untuk kontrol.
# 4) Bahas batch loader untuk membaca banyak gambar sekaligus dari folder.
# 5) Tutup dengan fungsi info gambar (dimensi, channel, aspek rasio).
# ============================================================

def load_image(image_path):
    """
    Load gambar dari file
    
    Args:
        image_path (str): Path ke file gambar
        
    Returns:
        numpy.ndarray: Gambar yang telah di-load, atau None jika gagal
    """
    # Cek apakah file exists
    if not os.path.exists(image_path):
        print(f"❌ Error: File tidak ditemukan - {image_path}")
        return None
    
    # Cek ekstensi file
    _, ext = os.path.splitext(image_path)
    if ext.lower() not in SUPPORTED_IMAGE_FORMATS:
        print(f"❌ Error: Format tidak didukung - {ext}")
        print(f"   Format yang didukung: {SUPPORTED_IMAGE_FORMATS}")
        return None
    
    # Load gambar
    image = cv2.imread(image_path)
    
    if image is None:
        print(f"❌ Error: Gagal membaca gambar - {image_path}")
        return None
    
    if LOG_ENABLED:
        print(f"✓ Berhasil load gambar: {image_path}")
        print(f"  Dimensi: {image.shape[1]}x{image.shape[0]}")
        print(f"  Channels: {image.shape[2] if len(image.shape) > 2 else 1}")
    
    return image


def capture_from_webcam(camera_index=WEBCAM_INDEX, preview_time=WEBCAM_WAIT_KEY):
    """
    Capture gambar dari webcam dengan preview
    
    Args:
        camera_index (int): Index kamera (default: 0)
        preview_time (int): Waktu preview dalam ms (default: dari config)
        
    Returns:
        numpy.ndarray: Gambar yang di-capture, atau None jika gagal
    """
    print(f"🎥 Membuka kamera index {camera_index}...")
    
    # Buka kamera
    cap = cv2.VideoCapture(camera_index)
    
    if not cap.isOpened():
        print(f"❌ Error: Tidak dapat membuka kamera index {camera_index}")
        return None
    
    print("✓ Kamera terbuka!")
    print("📸 Tekan SPACE untuk capture, ESC untuk cancel")
    
    captured_image = None
    
    try:
        while True:
            # Baca frame dari kamera
            ret, frame = cap.read()
            
            if not ret:
                print("❌ Error: Tidak dapat membaca frame dari kamera")
                break
            
            # Tampilkan preview
            display_frame = frame.copy()
            
            # Tambahkan overlay instruksi
            cv2.putText(display_frame, "SPACE: Capture | ESC: Cancel", 
                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 
                       0.7, (0, 255, 0), 2)
            
            # Tambahkan frame border untuk indikasi area capture
            h, w = display_frame.shape[:2]
            cv2.rectangle(display_frame, (10, 50), (w-10, h-10), (0, 255, 0), 2)
            
            cv2.imshow('SmartAttend - Webcam Capture', display_frame)
            
            # Tunggu key press
            key = cv2.waitKey(1) & 0xFF
            
            if key == 27:  # ESC key
                print("❌ Capture dibatalkan")
                break
            elif key == 32:  # SPACE key
                captured_image = frame.copy()
                print("✓ Gambar berhasil di-capture!")
                break
    
    finally:
        # Lepaskan kamera dan tutup window
        cap.release()
        cv2.destroyAllWindows()
    
    return captured_image


def load_multiple_images(folder_path, max_images=None):
    """
    Load multiple gambar dari sebuah folder
    
    Args:
        folder_path (str): Path ke folder yang berisi gambar
        max_images (int): Maksimal jumlah gambar yang akan di-load (None = semua)
        
    Returns:
        list: List berisi tuple (nama_file, gambar)
    """
    if not os.path.exists(folder_path):
        print(f"❌ Error: Folder tidak ditemukan - {folder_path}")
        return []
    
    images = []
    files = os.listdir(folder_path)
    
    # Filter hanya file gambar
    image_files = [f for f in files 
                   if os.path.splitext(f)[1].lower() in SUPPORTED_IMAGE_FORMATS]
    
    if max_images:
        image_files = image_files[:max_images]
    
    print(f"📁 Loading gambar dari: {folder_path}")
    print(f"   Total file gambar: {len(image_files)}")
    
    for filename in image_files:
        filepath = os.path.join(folder_path, filename)
        img = load_image(filepath)
        
        if img is not None:
            images.append((filename, img))
    
    print(f"✓ Berhasil load {len(images)} gambar")
    
    return images


def get_image_info(image):
    """
    Mendapatkan informasi detail tentang gambar
    
    Args:
        image (numpy.ndarray): Gambar yang akan dianalisis
        
    Returns:
        dict: Dictionary berisi informasi gambar
    """
    if image is None:
        return None
    
    info = {
        'width': image.shape[1],
        'height': image.shape[0],
        'channels': image.shape[2] if len(image.shape) > 2 else 1,
        'dtype': str(image.dtype),
        'size_bytes': image.nbytes,
        'aspect_ratio': image.shape[1] / image.shape[0]
    }
    
    return info


def display_image_info(image, title="Image Info"):
    """
    Menampilkan informasi gambar ke console
    
    Args:
        image (numpy.ndarray): Gambar yang akan ditampilkan infonya
        title (str): Judul informasi
    """
    info = get_image_info(image)
    
    if info is None:
        print("❌ Gambar tidak valid")
        return
    
    print(f"\n{'='*50}")
    print(f"  {title}")
    print(f"{'='*50}")
    print(f"  Dimensi       : {info['width']} x {info['height']}")
    print(f"  Channels      : {info['channels']}")
    print(f"  Data Type     : {info['dtype']}")
    print(f"  Size          : {info['size_bytes']:,} bytes")
    print(f"  Aspect Ratio  : {info['aspect_ratio']:.3f}")
    print(f"{'='*50}\n")


# ===== TESTING =====
if __name__ == "__main__":
    print("=== TESTING CAPTURE MODULE ===\n")
    
    # Test 1: Load single image
    print("Test 1: Load single image")
    test_image_path = os.path.join(INPUT_FOLDER, "sample_kartu.jpg")
    img = load_image(test_image_path)
    
    if img is not None:
        display_image_info(img, "Sample Kartu")
        cv2.imshow("Test Load Image", img)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    # Test 2: Load multiple images
    print("\nTest 2: Load multiple images")
    images = load_multiple_images(INPUT_FOLDER, max_images=5)
    print(f"Total images loaded: {len(images)}")
    
    # Test 3: Webcam capture (uncomment untuk test)
    # print("\nTest 3: Webcam capture")
    # captured = capture_from_webcam()
    # if captured is not None:
    #     display_image_info(captured, "Captured Image")
