# 🎓 SmartAttend System v1.0
## Sistem Pencatat Kehadiran Digital Berbasis Kartu Identitas

---

## 📖 Deskripsi Proyek

SmartAttend adalah sistem prototype untuk pencatatan kehadiran berbasis kartu identitas menggunakan teknologi Computer Vision. Sistem ini dapat mengambil foto kartu identitas, memproses gambar dengan berbagai transformasi, menambahkan anotasi, dan menyimpan hasil dengan organisasi yang terstruktur.

**Dibuat untuk**: Project Praktikum Komputer Vision - Modul 01  
**Teknologi**: Python, OpenCV, NumPy

---

## ✨ Fitur Utama

### Fitur Wajib (Sudah Diimplementasi)
- ✅ **Load/Capture Image**
  - Load gambar dari file (JPG, PNG, BMP, TIFF)
  - Capture gambar dari webcam dengan preview real-time
  
- ✅ **Image Processing Pipeline**
  - Resize ke ukuran standar (400x250 piksel)
  - Konversi ke grayscale
  - Adjust brightness dan contrast

- ✅ **Annotation**
  - Timestamp otomatis di pojok gambar
  - Border/frame di sekeliling gambar
  - Watermark "SmartAttend v1.0"

- ✅ **Save Output**
  - Format nama file: `YYYYMMDD_HHMMSS_kartu.jpg`
  - Organisasi folder berdasarkan tanggal
  - Kualitas output tinggi (95%)

- ✅ **Collage Generator**
  - Gabungkan multiple gambar dalam grid (2x2, 2x3, 3x3, 4x4)
  - Tampilan "Daily Summary" dengan judul dan timestamp
  - Simpan di folder terpisah

### Fitur Bonus (Sudah Diimplementasi)
- ✅ Menu interaktif di terminal
- ✅ Real-time webcam preview
- ✅ Batch processing untuk multiple images
- ✅ Statistics & monitoring
- ✅ Histogram equalization untuk gambar gelap
- ✅ Input validation dan error handling

---

## 📁 Struktur Project

```
Project_Sistem_Kartu/
├── main.py                 # Program utama dengan menu interaktif
├── capture_module.py       # Modul untuk load dan capture gambar
├── process_module.py       # Modul untuk pemrosesan gambar
├── utils.py               # Fungsi utilitas (save, statistics, dll)
├── config.py              # File konfigurasi
│
├── input/                 # Folder untuk gambar input
│   └── (letakkan gambar kartu di sini)
│
├── output/                # Folder untuk hasil pemrosesan
│   ├── 2024-01-15/       # Organisasi per tanggal
│   │   ├── 20240115_083045_kartu.jpg
│   │   └── ...
│   └── collages/         # Folder untuk collage
│       └── summary_2024-01-15.jpg
│
└── README.md             # Dokumentasi project (file ini)
```

---

## 🚀 Cara Menggunakan

### Instalasi

1. **Clone atau download project ini**

2. **Install dependencies**
   ```bash
   pip install opencv-python numpy
   ```

3. **Siapkan gambar input**
   - Letakkan gambar kartu identitas di folder `input/`
   - Format yang didukung: JPG, PNG, BMP, TIFF
   - **PENTING**: Sensor informasi sensitif pada kartu!

### Menjalankan Program

```bash
python main.py
```

### Menu Utama

```
┌──────────────────────────────────────────┐
│              MENU UTAMA                  │
├──────────────────────────────────────────┤
│  1. Process Single Image                 │
│  2. Process Multiple Images              │
│  3. Capture from Webcam                  │
│  4. Create Collage                       │
│  5. View Statistics                      │
│  6. Settings                             │
│  0. Exit                                 │
└──────────────────────────────────────────┘
```

### Penggunaan Setiap Menu

#### 1. Process Single Image
- Memproses satu gambar kartu identitas
- Dapat adjust brightness dan contrast
- Preview hasil sebelum menyimpan
- File disimpan dengan timestamp

#### 2. Process Multiple Images
- Batch processing untuk semua gambar di folder input
- Settings berlaku untuk semua gambar
- Otomatis ditawarkan untuk membuat collage

#### 3. Capture from Webcam
- Buka webcam dengan live preview
- Tekan SPACE untuk capture
- Tekan ESC untuk cancel
- Hasil langsung diproses dan dapat disimpan

#### 4. Create Collage
- Gabungkan beberapa gambar dalam grid
- Minimal 4 gambar diperlukan
- Grid size otomatis menyesuaikan jumlah gambar
- Hasil disimpan di folder `output/collages/`

#### 5. View Statistics
- Tampilkan jumlah kartu yang diproses hari ini
- Total kartu tersimpan
- Total ukuran storage
- Jumlah collages

#### 6. Settings
- Lihat konfigurasi saat ini
- Edit `config.py` untuk mengubah settings

---

## ⚙️ Konfigurasi

Edit file `config.py` untuk mengubah berbagai parameter:

### Parameter Utama
```python
CARD_WIDTH = 400           # Lebar kartu standar
CARD_HEIGHT = 250          # Tinggi kartu standar
OUTPUT_QUALITY = 95        # Kualitas JPEG (0-100)
WATERMARK_TEXT = "SmartAttend v1.0"
BORDER_COLOR = (0, 120, 255)  # Warna border (BGR)
BORDER_THICKNESS = 3
```

### Folder Paths
```python
INPUT_FOLDER = "input"
OUTPUT_FOLDER = "output"
COLLAGE_FOLDER = "output/collages"
```

### Collage Settings
```python
COLLAGE_GRID_SIZE = (2, 2)  # Grid 2x2
COLLAGE_PADDING = 10
COLLAGE_TITLE_HEIGHT = 50
```

---

## 🖼️ Contoh Output

### Output Individual Card
```
┌─────────────────────────────────┐
│  [Gambar Kartu - 400x250px]     │
│                                 │
│  📅 2024-01-15 08:30:45         │
│  SmartAttend System v1.0        │
└─────────────────────────────────┘
```

### Output Collage (2x2)
```
┌─────────────────────────────────────┐
│     DAILY SUMMARY: 2024-01-15       │
├────────────────┬────────────────────┤
│   Card #1      │      Card #2       │
│   08:30:45     │      09:15:22      │
├────────────────┼────────────────────┤
│   Card #3      │      Card #4       │
│   10:00:15     │      11:45:33      │
└────────────────┴────────────────────┘
```

---

## 🧪 Testing

### Test Individual Modules

Setiap modul dapat di-test secara independen:

```bash
# Test config
python config.py

# Test capture module
python capture_module.py

# Test process module
python process_module.py

# Test utils
python utils.py
```

---

## 📊 Workflow Program

```
Input Image
    │
    ▼
Load/Capture ──► Validation
    │
    ▼
Resize to Standard Size (400x250)
    │
    ▼
Adjust Brightness/Contrast (optional)
    │
    ▼
Add Timestamp
    │
    ▼
Add Watermark
    │
    ▼
Add Border
    │
    ▼
Save with Organization (YYYY-MM-DD/YYYYMMDD_HHMMSS_kartu.jpg)
    │
    ▼
Statistics Update
```

---

## 🛠️ Teknologi & Library

- **Python 3.7+**: Bahasa pemrograman
- **OpenCV (cv2)**: Library computer vision untuk pemrosesan gambar
- **NumPy**: Library untuk operasi array dan matrix
- **datetime**: Untuk timestamp dan organisasi folder

---

## 📋 Requirements

```txt
opencv-python>=4.5.0
numpy>=1.19.0
```

Install dengan:
```bash
pip install -r requirements.txt
```

---

## 🎯 Fitur yang Dapat Dikembangkan

### Enhancement Ideas
- [ ] GUI menggunakan Tkinter atau PyQt
- [ ] Auto-rotation detection untuk kartu
- [ ] OCR untuk ekstrak informasi dari kartu
- [ ] QR Code generation untuk setiap kartu
- [ ] Database integration (SQLite)
- [ ] Web interface dengan Flask/Django
- [ ] Export report ke PDF
- [ ] Auto-blur untuk informasi sensitif
- [ ] Face detection pada kartu
- [ ] Barcode/QR code scanning

---

## ⚠️ Catatan Penting

1. **Privacy**: Selalu sensor/blur informasi sensitif pada kartu identitas (NIK, alamat, dll)
2. **Format Gambar**: Pastikan gambar input dalam format yang didukung
3. **Pencahayaan**: Untuk hasil terbaik, gunakan pencahayaan yang baik
4. **Webcam**: Fitur webcam memerlukan kamera aktif
5. **Storage**: Pastikan ada cukup ruang disk untuk menyimpan output

---

## 🐛 Troubleshooting

### Masalah: Webcam tidak terbuka
**Solusi**: 
- Pastikan webcam terhubung dan tidak digunakan aplikasi lain
- Coba ubah `WEBCAM_INDEX` di `config.py` (0, 1, 2, dst)

### Masalah: Error saat load gambar
**Solusi**:
- Pastikan format gambar didukung
- Check path file sudah benar
- Pastikan file tidak corrupt

### Masalah: Output folder tidak dibuat otomatis
**Solusi**:
- Program akan membuat folder otomatis
- Pastikan ada permission untuk menulis ke disk

### Masalah: Gambar terlalu gelap/terang
**Solusi**:
- Gunakan adjustment brightness/contrast
- Atau gunakan histogram equalization

---

## 👨‍💻 Developer

**Nama**: [Isi Nama Anda]  
**NIM**: [Isi NIM Anda]  
**Kelas**: [Isi Kelas Anda]  
**Mata Kuliah**: Praktikum Komputer Vision  
**Dosen**: [Isi Nama Dosen]

---

## 📚 Referensi

1. OpenCV Documentation: https://docs.opencv.org/
2. NumPy Documentation: https://numpy.org/doc/
3. Python datetime: https://docs.python.org/3/library/datetime.html
4. Computer Vision Course Materials

---

## 📄 License

Project ini dibuat untuk keperluan edukatif dalam rangka praktikum Komputer Vision.

---

## 🙏 Acknowledgments

Terima kasih kepada:
- Dosen dan asisten praktikum
- OpenCV Community
- Python Community
- Teman-teman sekelompok

---

**Dibuat dengan ❤️ untuk Praktikum Computer Vision**

*"Perjalanan seribu mil dimulai dari satu langkah - dan langkah pertama dalam Computer Vision dimulai dari sini!"*
