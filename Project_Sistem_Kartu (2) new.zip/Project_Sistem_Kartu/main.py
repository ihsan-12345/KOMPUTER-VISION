# main.py
# Program Utama - Sistem Pencatat Kehadiran Digital Berbasis Kartu Identitas

import cv2
import sys
from datetime import datetime

# ============================================================
# KOMENTAR VIDEO (alur demo proyek sistem kartu)
# 1) Jelaskan ini adalah entry point aplikasi menu interaktif.
# 2) Tunjukkan alur utama: pilih menu → proses pipeline → preview → simpan.
# 3) Sorot mode utama: single image, batch image, webcam capture, collage.
# 4) Bahas fitur bonus: quality check, auto-enhancement, duplicate detection.
# 5) Tutup dengan export report sebagai output evaluasi hasil praktikum.
# ============================================================

# Import modul-modul yang sudah dibuat
from config import *
from capture_module import *
from process_module import *
from utils import *
from enhancement_module import *


def wait_preview_input(timeout_ms=8000):
    """
    Tunggu input dari jendela OpenCV dengan fallback auto-lanjut.
    """
    print("Fokus ke jendela gambar lalu tekan tombol apa saja.")
    print(f"Jika tidak ada input, lanjut otomatis dalam {timeout_ms // 1000} detik...")

    cv2.waitKey(1)
    key = cv2.waitKey(timeout_ms)
    cv2.destroyAllWindows()

    if key == -1:
        print("⏱️ Tidak ada tombol ditekan, lanjut otomatis.")


def normalize_input_path(path_text):
    """
    Bersihkan input path dari kutip dan spasi berlebih.
    """
    if path_text is None:
        return ""
    cleaned = path_text.strip().strip('"').strip("'")
    return os.path.expanduser(cleaned)

def process_single_image():
    """
    Proses satu gambar kartu identitas
    """
    print("\n" + "="*60)
    print("             PROSES SINGLE IMAGE")
    print("="*60)
    
    # Minta input path gambar
    image_path = normalize_input_path(input("\nMasukkan path gambar (atau tekan Enter untuk contoh): "))
    
    if not image_path:
        # Cari gambar di folder input
        files = get_files_in_folder(INPUT_FOLDER)
        if not files:
            print("❌ Tidak ada gambar di folder input")
            return
        image_path = files[0]
        print(f"📁 Menggunakan: {image_path}")
    
    # Load gambar
    print("\n📥 Loading gambar...")
    image = load_image(image_path)
    
    if image is None:
        return
    
    # Tampilkan info gambar asli
    display_image_info(image, "GAMBAR ASLI")
    
    # Pipeline pemrosesan
    print("⚙️  Memulai pipeline pemrosesan...\n")
    
    # 1. Resize ke ukuran standar
    processed = resize_standard(image)
    
    # 2. Adjust brightness/contrast (opsional)
    brightness = get_user_input("Brightness adjustment (-100 to 100, default 0)", int, 0, (-100, 100))
    contrast = get_user_input("Contrast multiplier (0.5 to 3.0, default 1.0)", float, 1.0, (0.5, 3.0))
    processed = adjust_brightness_contrast(processed, brightness, contrast)
    
    # 3. Tambahkan timestamp
    processed = add_timestamp(processed)
    
    # 4. Tambahkan watermark
    processed = add_watermark(processed)
    
    # 5. Tambahkan border
    processed = add_border(processed)
    
    # Preview hasil
    print("\n👁️  Preview hasil...")
    cv2.imshow("Original", image)
    cv2.imshow("Processed", processed)
    wait_preview_input()
    
    # Simpan hasil
    if confirm_action("Simpan hasil?"):
        filepath = save_with_organization(processed)
        if filepath:
            print(f"\n✅ Berhasil! File disimpan di: {filepath}")
    
    print()


def process_multiple_images():
    """
    Proses beberapa gambar sekaligus
    """
    print("\n" + "="*60)
    print("           PROSES MULTIPLE IMAGES")
    print("="*60)
    
    # Load semua gambar dari folder input
    print(f"\n📁 Loading gambar dari folder: {INPUT_FOLDER}")
    images = load_multiple_images(INPUT_FOLDER)
    
    if not images:
        print("❌ Tidak ada gambar untuk diproses")
        return
    
    print(f"\n✓ Ditemukan {len(images)} gambar")
    
    if not confirm_action(f"Proses {len(images)} gambar?"):
        return
    
    # Tanyakan settings
    brightness = get_user_input("Brightness adjustment untuk semua (-100 to 100, default 0)", 
                                int, 0, (-100, 100))
    contrast = get_user_input("Contrast multiplier untuk semua (0.5 to 3.0, default 1.0)", 
                             float, 1.0, (0.5, 3.0))
    
    # Proses setiap gambar
    processed_count = 0
    print("\n⚙️  Memulai batch processing...\n")
    
    for idx, (filename, image) in enumerate(images, 1):
        print(f"[{idx}/{len(images)}] Processing: {filename}")
        
        # Pipeline pemrosesan
        processed = resize_standard(image)
        processed = adjust_brightness_contrast(processed, brightness, contrast)
        processed = add_timestamp(processed)
        processed = add_watermark(processed)
        processed = add_border(processed)
        
        # Simpan
        filepath = save_with_organization(processed)
        if filepath:
            processed_count += 1
    
    print(f"\n✅ Selesai! Berhasil memproses {processed_count}/{len(images)} gambar")
    
    # Tanyakan apakah ingin buat collage
    if processed_count >= 4:
        if confirm_action("\nBuat collage dari hasil?"):
            create_collage_menu()


def capture_from_webcam_menu():
    """
    Menu untuk capture dari webcam
    """
    print("\n" + "="*60)
    print("             CAPTURE FROM WEBCAM")
    print("="*60)
    
    print("\n📷 Membuka webcam...")
    print("   SPACE: Capture gambar")
    print("   ESC: Cancel\n")
    
    # Capture dari webcam
    captured = capture_from_webcam()
    
    if captured is None:
        return
    
    # Proses gambar yang di-capture
    print("\n⚙️  Memproses gambar...\n")
    processed = resize_standard(captured)
    processed = add_timestamp(processed)
    processed = add_watermark(processed)
    processed = add_border(processed)
    
    # Preview
    cv2.imshow("Captured & Processed", processed)
    wait_preview_input()
    
    # Simpan
    if confirm_action("Simpan hasil?"):
        filepath = save_with_organization(processed)
        if filepath:
            print(f"\n✅ Berhasil! File disimpan di: {filepath}")


def create_collage_menu():
    """
    Menu untuk membuat collage
    """
    print("\n" + "="*60)
    print("               CREATE COLLAGE")
    print("="*60)
    
    # Ambil gambar dari output hari ini
    today = datetime.now().strftime("%Y-%m-%d")
    today_folder = os.path.join(OUTPUT_FOLDER, today)
    
    if not os.path.exists(today_folder):
        print(f"\n❌ Folder untuk hari ini tidak ditemukan: {today_folder}")
        print("   Proses beberapa gambar terlebih dahulu!")
        return
    
    # Load gambar-gambar
    image_files = get_files_in_folder(today_folder, extension='.jpg')
    
    if len(image_files) < 4:
        print(f"\n❌ Minimal 4 gambar diperlukan untuk collage")
        print(f"   Saat ini hanya ada {len(image_files)} gambar")
        return
    
    print(f"\n✓ Ditemukan {len(image_files)} gambar")
    
    # Muat 4 gambar pertama (atau lebih)
    num_images = min(len(image_files), 
                     get_user_input("Berapa gambar untuk collage? (4 recommended)", 
                                   int, 4, (4, 16)))
    
    selected_files = image_files[:num_images]
    
    print(f"\n📥 Loading {len(selected_files)} gambar...")
    images = []
    timestamps = []
    
    for filepath in selected_files:
        img = load_image(filepath)
        if img is not None:
            images.append(img)
            # Extract timestamp dari nama file
            filename = os.path.basename(filepath)
            try:
                # Format: YYYYMMDD_HHMMSS_kartu.jpg
                time_part = filename.split('_')[1]
                time_str = f"{time_part[:2]}:{time_part[2:4]}:{time_part[4:6]}"
                timestamps.append(time_str)
            except:
                timestamps.append("")
    
    if len(images) < 4:
        print("❌ Gagal load cukup gambar untuk collage")
        return
    
    # Buat collage
    print("\n⚙️  Membuat collage...\n")
    # Hitung grid size yang optimal
    if num_images <= 4:
        grid_size = (2, 2)
    elif num_images <= 6:
        grid_size = (2, 3)
    elif num_images <= 9:
        grid_size = (3, 3)
    else:
        grid_size = (4, 4)
    
    collage = create_collage(images, grid_size=grid_size, timestamps=timestamps)
    
    if collage is None:
        return
    
    # Tampilkan preview
    # Resize untuk preview (agar tidak terlalu besar)
    preview_height = 600
    preview_width = int(collage.shape[1] * (preview_height / collage.shape[0]))
    preview = cv2.resize(collage, (preview_width, preview_height))
    
    cv2.imshow("Collage Preview", preview)
    wait_preview_input()
    
    # Simpan collage
    if confirm_action("Simpan collage?"):
        filepath = save_collage(collage)
        if filepath:
            print(f"\n✅ Berhasil! Collage disimpan di: {filepath}")


def settings_menu():
    """
    Menu untuk melihat dan mengubah settings
    """
    print("\n" + "="*60)
    print("                   SETTINGS")
    print("="*60)
    
    print("\n📋 Current Settings:")
    print(f"   Ukuran Kartu: {CARD_WIDTH}x{CARD_HEIGHT}")
    print(f"   Output Quality: {OUTPUT_QUALITY}")
    print(f"   Watermark: {WATERMARK_TEXT}")
    print(f"   Border Color: {BORDER_COLOR} (BGR)")
    print(f"   Border Thickness: {BORDER_THICKNESS}")
    print(f"   Collage Grid: {COLLAGE_GRID_SIZE[0]}x{COLLAGE_GRID_SIZE[1]}")
    print(f"   Input Folder: {INPUT_FOLDER}")
    print(f"   Output Folder: {OUTPUT_FOLDER}")
    
    print("\n💡 Info: Untuk mengubah settings, edit file config.py")
    
    input("\nTekan Enter untuk kembali...")


def quality_check_menu():
    """
    Menu untuk check kualitas gambar
    """
    print("\n" + "="*60)
    print("             IMAGE QUALITY CHECK")
    print("="*60)
    
    print("\n📸 Load gambar untuk di-check...")
    image_path = normalize_input_path(input("Masukkan path gambar: "))
    
    if not image_path:
        # Cari gambar di folder input
        files = get_files_in_folder(INPUT_FOLDER)
        if not files:
            print("❌ Tidak ada gambar di folder input")
            return
        image_path = files[0]
        print(f"📁 Menggunakan: {image_path}")
    
    image = load_image(image_path)
    if image is None:
        return
    
    # Check kualitas
    print("\n🔍 Checking image quality...\n")
    display_quality_report(image, "Image Quality Analysis")
    
    # Deteksi orientasi
    print("📐 Card Orientation Detection:")
    orientation = detect_card_orientation(image)
    print(f"   Orientation: {orientation['orientation']}")
    print(f"   Aspect Ratio: {orientation['aspect_ratio']:.2f}")
    print(f"   Confidence: {orientation['confidence']}\n")
    
    # Deteksi wajah
    print("👤 Face Detection:")
    faces = detect_face(image)
    if len(faces) > 0:
        print(f"   ✅ {len(faces)} wajah terdeteksi")
        img_with_faces = draw_face_rectangles(image, faces)
        cv2.imshow("Face Detection", img_with_faces)
        wait_preview_input()
    else:
        print("   ⚠️  Tidak ada wajah terdeteksi")
        print("   ℹ️ Ini umum pada foto KTM jika wajah kecil, blur, atau silau.")
        print("   💡 Coba: foto lebih dekat, cahaya lebih terang, dan minim pantulan.")
        if confirm_action("   Jalankan auto-enhancement lalu coba deteksi lagi?", default=True):
            enhanced = auto_enhance_image(image, apply_histogram_eq=True, apply_clahe=True)
            retry_faces = detect_face(enhanced)
            if len(retry_faces) > 0:
                print(f"   ✅ Setelah enhancement: {len(retry_faces)} wajah terdeteksi")
                retry_img = draw_face_rectangles(enhanced, retry_faces)
                cv2.imshow("Face Detection (Enhanced)", retry_img)
                wait_preview_input()
            else:
                print("   ⚠️ Masih belum terdeteksi. Lanjut proses tanpa face detection.")
    
    input("\nTekan Enter untuk kembali...")


def enhancement_menu():
    """
    Menu untuk auto enhancement gambar
    """
    print("\n" + "="*60)
    print("           AUTO IMAGE ENHANCEMENT")
    print("="*60)
    
    print("\n📸 Load gambar untuk di-enhance...")
    image_path = normalize_input_path(input("Masukkan path gambar: "))
    
    if not image_path:
        files = get_files_in_folder(INPUT_FOLDER)
        if not files:
            print("❌ Tidak ada gambar di folder input")
            return
        image_path = files[0]
        print(f"📁 Menggunakan: {image_path}")
    
    image = load_image(image_path)
    if image is None:
        return
    
    print("\n⚙️  Applying auto enhancement...\n")
    
    # Show original quality
    print("SEBELUM Enhancement:")
    display_quality_report(image)
    
    # Apply enhancement
    enhanced = auto_enhance_image(image, apply_histogram_eq=True, apply_clahe=True)
    
    # Show enhanced quality
    print("SESUDAH Enhancement:")
    display_quality_report(enhanced)
    
    # Preview
    print("👁️  Preview hasil...")
    cv2.imshow("Original", image)
    cv2.imshow("Enhanced", enhanced)
    wait_preview_input()
    
    # Simpan
    if confirm_action("Simpan hasil enhancement?"):
        filepath = save_with_organization(enhanced, filename="enhanced_kartu.jpg")
        if filepath:
            print(f"\n✅ Berhasil! File disimpan di: {filepath}")
    
    input("\nTekan Enter untuk kembali...")


def duplicate_detection_menu():
    """
    Menu untuk deteksi gambar duplikat
    """
    print("\n" + "="*60)
    print("         DUPLICATE IMAGE DETECTION")
    print("="*60)
    
    print(f"\n📁 Scanning folder: {INPUT_FOLDER}")
    images = load_multiple_images(INPUT_FOLDER)
    
    if len(images) < 2:
        print("❌ Minimal 2 gambar diperlukan untuk deteksi duplikat")
        return
    
    print(f"✓ Loaded {len(images)} images")
    
    # Hitung threshold
    threshold = get_user_input("Similarity threshold (0.7-0.99, default 0.95)", 
                              float, 0.95, (0.7, 0.99))
    
    print(f"\n🔍 Scanning for duplicates (threshold: {threshold})...\n")
    
    duplicates = find_duplicate_images(images, threshold=threshold)
    
    if len(duplicates) == 0:
        print("✅ Tidak ada gambar duplikat ditemukan!")
    else:
        print(f"⚠️  Ditemukan {len(duplicates)} grup duplikat:\n")
        
        for i, group in enumerate(duplicates, 1):
            print(f"Group {i}:")
            for filename in group:
                print(f"  - {filename}")
            print()
    
    input("Tekan Enter untuk kembali...")


def export_report_menu():
    """
    Menu untuk export statistik report
    """
    print("\n" + "="*60)
    print("              EXPORT REPORT")
    print("="*60)
    
    print(f"\n📁 Report akan dibuat dari folder: {OUTPUT_FOLDER}")
    
    # Pilih format
    print("\nPilih format export:")
    print("1. JSON")
    print("2. CSV")
    
    choice = input("Pilih (1-2): ").strip()
    
    format_map = {'1': 'json', '2': 'csv'}
    format_choice = format_map.get(choice, 'json')
    
    print(f"\n📝 Generating report ({format_choice.upper()})...\n")
    
    report_path = export_statistics_report(OUTPUT_FOLDER, format=format_choice)
    
    if report_path:
        print(f"\n✅ Report successfully exported!")
        print(f"   Location: {report_path}")
        
        if confirm_action("Open report file?"):
            if os.name == 'nt':  # Windows
                os.system(f'start {report_path}')
            else:
                os.system(f'open {report_path}')
    
    input("\nTekan Enter untuk kembali...")


def main():
    """
    Fungsi utama program
    """
    # Pastikan folder-folder ada
    try:
        ensure_directories()
    except Exception as e:
        print(f"❌ Error saat membuat direktori: {e}")
        input("Tekan Enter untuk lanjut...")
    
    while True:
        try:
            # Clear screen dan tampilkan banner
            clear_terminal()
            print_banner()
            print_menu()
            
            # Ambil pilihan user
            choice = input("Pilih menu (0-10): ").strip()
            
            if choice == '1':
                process_single_image()
            elif choice == '2':
                process_multiple_images()
            elif choice == '3':
                capture_from_webcam_menu()
            elif choice == '4':
                create_collage_menu()
            elif choice == '5':
                show_statistics()
                input("\nTekan Enter untuk kembali...")
            elif choice == '7':
                quality_check_menu()
            elif choice == '8':
                enhancement_menu()
            elif choice == '9':
                duplicate_detection_menu()
            elif choice == '10':
                export_report_menu()
            elif choice == '6':
                settings_menu()
            elif choice == '0':
                print("\n👋 Terima kasih telah menggunakan SmartAttend!")
                print("   Sampai jumpa!\n")
                sys.exit(0)
            else:
                print("\n❌ Pilihan tidak valid!")
                input("Tekan Enter untuk melanjutkan...")
                
        except KeyboardInterrupt:
            print("\n\n⚠️ Input dibatalkan. Kembali ke menu utama...")
            continue
        except EOFError:
            print("\n\n❌ Input stream terminated")
            print("   Program dihentikan\n")
            sys.exit(1)
        except Exception as e:
            print(f"\n❌ Error: {e}")
            print(f"   Type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            input("\nTekan Enter untuk melanjutkan...")


if __name__ == "__main__":
    try:
        print("🚀 Starting SmartAttend System...")
        print("   Checking configuration...")
        
        # Validasi konfigurasi
        try:
            validate_config()
            print("   ✅ Configuration OK")
        except AssertionError as e:
            print(f"❌ Konfigurasi tidak valid: {e}")
            sys.exit(1)
        except Exception as e:
            print(f"❌ Error checking config: {e}")
            sys.exit(1)
        
        # Jalankan program utama
        main()
        
    except KeyboardInterrupt:
        print("\n\n👋 Program dihentikan oleh user")
        print("   Sampai jumpa!\n")
    except Exception as e:
        print(f"\n\n❌ Fatal Error: {e}")
        print(f"   Type: {type(e).__name__}")
        import traceback
        traceback.print_exc()
        input("\nTekan Enter untuk keluar...")
